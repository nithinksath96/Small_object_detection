dataDir="/data2/mengtial"

methodName=rt_dat_mrcnn50_nm_track_only_s0.5_d15

python forecast/pps_forecast.py \
	--data-root "${dataDir}/ArgoVerse/tracking" \
	--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--fps 30 \
	--assoc given \
	--forecast linear \
	--in-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}/val" \
	--out-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}_linear/val" \
	--overwrite \
	# --vis-dir "${dataDir}/Exp/ArgoVerse-debug/vis/${methodName}_itp/s0.5_val" \
	# --vis-scale 0.5 \
