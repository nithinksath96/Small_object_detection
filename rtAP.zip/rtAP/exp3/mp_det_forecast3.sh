dataDir="/data2/mengtial"
ssdDir=$dataDir
# ssdDir="/scratch/mengtial"

methodName=mrcnn_r50_nm_iou_lin
scales="0.5"

for s in ${scales}
do
	python forecast/mp_det_forecast.py \
		--data-root "${ssdDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	    --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--weights "${ssdDir}/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--no-mask \
		--in-scale ${s} \
		--fps 30 \
		--assoc iou \
		--forecast linear \
		--out-dir "${dataDir}/Exp/ArgoVerse-debug/output/mp_${methodName}/s${s}_val" \
		--overwrite \
		&&
	python det/rt_assoc_eval.py \
		--data-root "${ssdDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--fps 30 \
		--result-dir "${dataDir}/Exp/ArgoVerse-debug/output/mp_${methodName}/s${s}_val" \
		--overwrite \

		# --vis-dir "${dataDir}/Exp/ArgoVerse-debug/vis/mp_${methodName}/s${s}_val" \
		# --vis-scale 0.5 \

done

		# --forecast-before-assoc \