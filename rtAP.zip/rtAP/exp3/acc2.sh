dataDir="/data2/mengtial"

methodName=mrcnn_r50
# scales="0.25 0.5 0.75"
scales="1"


for s in ${scales}
do
	# python det/det_coco_fmt.py \
	# 	--data-root "${dataDir}/ArgoVerse1.1/tracking" \
	# 	--annot-path "${dataDir}/ArgoVerse1.1/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	#     --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	# 	--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	# 	--in-scale ${s} \
	# 	--out-dir "${dataDir}/Exp/ACC1/output/${methodName}/s${s}_val" \
	# 	--vis-dir "${dataDir}/Exp/ACC1/vis/${methodName}/s${s}_val" \
	# 	--vis-scale 0.5 \
	# 	--overwrite \

	python det/eval_coco_fmt.py \
		--data-root "${dataDir}/ArgoVerse1.1/tracking" \
		--annot-path "${dataDir}/ArgoVerse1.1/tracking/coco_fmt/acc2_htc_dconv2_ms_val.json" \
		--result-path "${dataDir}/Exp/ACC1/output/${methodName}/s${s}_val/results_ccf.pkl" \
		--out-dir "${dataDir}/Exp/ACC1/output/${methodName}/s${s}_val" \
		--overwrite \

done