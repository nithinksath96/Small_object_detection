dataDir="/data2/mengtial"

methodName=mrcnn_r50_nm
scales="0.5"

for s in ${scales}
do
	python det/mp_det_coco_fmt_pipe_fidx.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	    --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--no-mask \
		--in-scale ${s} \
		--fps 30 \
		--out-dir "${dataDir}/Exp/ArgoVerse-pgt-c1/output/mp_${methodName}/s${s}_val" \
		--overwrite \
		&&
	python det/rt_assoc_eval.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--fps 30 \
		--result-dir "${dataDir}/Exp/ArgoVerse-pgt-c1/output/mp_${methodName}/s${s}_val" \
		--overwrite \

		# --vis-dir "${dataDir}/Exp/ArgoVerse-debug/vis/mp_${methodName}/s${s}_val" \
		# --vis-scale 0.5 \

done
