dataDir="/data2/mengtial"

methodName=srt_mrcnn_r50_nm_ds

python track/pps_sort.py \
	--data-root "${dataDir}/ArgoVerse/tracking" \
	--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--fps 30 \
	--in-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}/s0.5_val" \
	--out-dir "${dataDir}/Exp/ArgoVerse-debug/output/${methodName}_sort/s0.5_val" \
	--overwrite \
	# --vis-dir "${dataDir}/Exp/ArgoVerse-debug/vis/${methodName}_sort/s0.5_val" \
	# --vis-scale 0.5 \

