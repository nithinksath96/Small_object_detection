dataDir="/data2/mengtial"

methodName=srt_mrcnn_r50_nm_ds

python track/pps_iou_lin_extrap.py \
	--data-root "${dataDir}/ArgoVerse/tracking" \
	--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--fps 30 \
	--max-det 100 \
	--result-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}/s0.5_val" \
	--out-dir "${dataDir}/Exp/ArgoVerse-debug2/output/${methodName}_itp/s0.5_val" \
	--overwrite \
