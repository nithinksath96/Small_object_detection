dataDir="/data2/mengtial"

methodName=mrcnn_r50
scales="0.25 0.5 0.75 1"

for s in ${scales}
do
	python det/det_coco_fmt.py \
		--data-root "${dataDir}/ArgoVerse1.1/tracking" \
		--annot-path "${dataDir}/ArgoVerse1.1/tracking/coco_fmt/htc_dconv2_ms_val_common.json" \
	    --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--in-scale ${s} \
		--out-dir "${dataDir}/Exp/AVCommon1.1/output/${methodName}/s${s}_val" \
		--vis-dir "${dataDir}/Exp/AVCommon1.1/vis/${methodName}/s${s}_val" \
		--vis-scale 0.5 \
		--overwrite \

done
