dataDir="/data2/mengtial"

methodName=mrcnn50_nm_s0.5

python forecast/pps_forecast.py \
	--data-root "${dataDir}/ArgoVerse/tracking" \
	--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--fps 30 \
	--assoc iou \
	--forecast linear \
	--in-dir "${dataDir}/Exp/ArgoVerse-pgt-gpupre/output/rt_${methodName}/val" \
	--out-dir "${dataDir}/Exp/ArgoVerse-pgt-gpupre/output/pps_${methodName}_fba_iou_linear/val" \
	--overwrite \
	--forecast-before-assoc \
	# --vis-dir "${dataDir}/Exp/ArgoVerse-pgt-gpupre/vis/${methodName}_fba_iou_linear/val" \
	# --vis-scale 0.5 \


