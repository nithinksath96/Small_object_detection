sh exp1/rt_det_mrcnn_r50_2.sh
sh exp2/rt_det_as_track_multirun.sh
sh exp1/rt_det_htc_dconv2_ms_val.sh
