dataDir="/data2/mengtial"

methodName=srt_mrcnn_r50_nm_ds

python forecast/pps_forecast.py \
	--data-root "${dataDir}/ArgoVerse/tracking" \
	--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--fps 30 \
	--assoc iou \
	--forecast quadratic \
	--in-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}/s0.5_val" \
	--out-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}_fba_iou_quadratic/s0.5_val" \
	--overwrite \
	--forecast-before-assoc \
	--vis-dir "${dataDir}/Exp/ArgoVerse/vis/${methodName}_fba_iou_quadratic/s0.5_val" \
	--vis-scale 0.5 \


