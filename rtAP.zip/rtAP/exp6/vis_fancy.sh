dataDir="/data2/mengtial"

methodName=pps_mrcnn50_nm_ds_s0.5_kf_fba_iou_lin


python vis/vis_det_fancy.py \
	--data-root "${dataDir}/ArgoVerse1.1/tracking" \
	--annot-path "${dataDir}/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-path "${dataDir}/Exp/ArgoVerse1.1/output/${methodName}/val/results_ccf.pkl" \
	--vis-dir "${dataDir}/Exp/ArgoVerse1.1/visf/${methodName}/val" \
	--seq b1ca08f1-24b0-3c39-ba4e-d5a92868462c \
	--overwrite \

	# --score-th 0.5 \

