dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=retina50

python det/det_coco.py \
	--data-root "${dataDir}/COCO/val2017" \
	--annot-path "${dataDir}/COCO/annotations/instances_val2017.json" \
	--config "~/repo/mmdetection/configs/retinanet_r50_fpn_1x.py" \
	--weights "${dataDir2}/ModelZoo/mmdet/retinanet_r50_fpn_2x_20190616-75574209.pth" \
	--no-mask \
	--out-dir "${dataDir2}/Exp/COCO/output/${methodName}/val" \
	--vis-dir "${dataDir2}/Exp/COCO/vis/${methodName}/val" \
	--vis-scale 0.5 \
	--overwrite \
