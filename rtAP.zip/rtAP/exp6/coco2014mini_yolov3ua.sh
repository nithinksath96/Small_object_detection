dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=yolov3ua

python det/det_coco.py \
	--data-root "${dataDir}/COCO/val2014" \
	--annot-path "${dataDir}/COCO/annotations/instances_minival2014.json" \
	--config "det/yolo_v3_ua/yolov3ua.py" \
	--weights "${dataDir2}/ModelZoo/yolo/yolov3.pt" \
	--no-mask \
	--out-dir "${dataDir2}/Exp/COCO/output/${methodName}/minival2014" \
	--overwrite \
	# --vis-dir "${dataDir2}/Exp/COCO/vis/${methodName}/minival2014" \
	# --vis-scale 1 \


