dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ModelZoo/mmdet" ]; then
  ssdDir="$dataDir"
fi

dbName="bag1"
# vidPath="$dataDir/Captures/WIN_20200221_14_58_26_Pro.mp4"
vidDBDir="$dataDir/RC/bag1"
config="$HOME/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py"
weights="$ssdDir/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth"
fps=60

imgFolder="$vidDBDir/bag1"

# mkdir -p "$imgFolder"
# ffmpeg -i "$vidPath" -qscale:v 2 "$imgFolder/%06d.jpg"

# # Verify FPS
# fps=`ffmpeg -i "$vidPath" 2>&1 | sed -n "s/.*, \(.*\) fp.*/\1/p"`
# echo FPS (ffmpeg): $fps


python util/add_to_runtime_zoo.py \
	--time-info "$dataDir/Exp/RC/$dbName/output/rt_mrcnn50_nm_ds_s0.5/time_info.pkl" \
	--out-path "$dataDir/Exp/RC/$dbName/runtime-zoo/1080ti/mrcnn50_nm_s0.5.pkl" \
	--overwrite \
	&&
python det/srt_det_coco_fmt.py \
	--no-mask \
	--fps $fps \
	--overwrite \
	--dynamic-schedule \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--config "$config" \
	--weights "$weights" \
	--runtime "$dataDir/Exp/RC/$dbName/runtime-zoo/1080ti/mrcnn50_nm_s0.5.pkl" \
	--perf-factor 0.1 \
	--in-scale 0.5 \
	--out-dir "$dataDir/Exp/RC/$dbName/output/srt_mrcnn50_nm_ds_s0.5_pf0.1/" \
	&&
python forecast/pps_forecast.py \
	--fps $fps \
	--eta 0 \
	--assoc iou \
	--forecast linear \
	--forecast-before-assoc \
	--overwrite \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--in-dir "$dataDir/Exp/RC/$dbName/output/srt_mrcnn50_nm_ds_s0.5_pf0.1/" \
	--out-dir "$dataDir/Exp/RC/$dbName/output/srt_mrcnn50_nm_ds_s0.5_pf0.1_fba_iou_lin/" \
	--no-eval \
	&&
python det/filter_pickup_truck.py \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--in-dir "$dataDir/Exp/RC/$dbName/output/srt_mrcnn50_nm_ds_s0.5_pf0.1_fba_iou_lin/" \
	--out-dir "$dataDir/Exp/RC/$dbName/output/srt_mrcnn50_nm_ds_s0.5_pf0.1_fba_iou_lin_pkt/" \
	--overwrite \
	--no-eval \
	&&
python vis/vis_det_fancy.py \
	--fps $fps \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--result-path "$dataDir/Exp/RC/$dbName/output/srt_mrcnn50_nm_ds_s0.5_pf0.1_fba_iou_lin_pkt/results_ccf.pkl" \
	--vis-dir "$dataDir/Exp/RC/$dbName/visf/srt_mrcnn50_nm_ds_s0.5_pf0.1_fba_iou_lin_pkt/" \
	--overwrite \
	&&
echo http://trinity.vision.cs.cmu.edu:40001/Exp/RC/$dbName/visf/srt_mrcnn50_nm_ds_s0.5_pf0.1_fba_iou_lin_pkt/bag1.mp4
