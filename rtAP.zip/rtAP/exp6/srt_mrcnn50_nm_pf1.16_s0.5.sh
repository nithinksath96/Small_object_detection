dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


# python det/srt_det_coco_fmt.py \
# 	--perf-factor 1.16 \
# 	--no-mask \
# 	--fps 30 \
# 	--overwrite \
# 	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
# 	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
# 	--cached-res "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/mrcnn50_nm_s0.5/val/results_raw.pkl" \
# 	--runtime "$dataDir/Exp/ArgoVerse1.1/runtime-zoo/1080ti/mrcnn50_nm_s0.5.pkl" \
# 	--in-scale 0.5 \
# 	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_mrcnn50_nm_pf1.16_s0.5/val" \
#     && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_mrcnn50_nm_pf1.16_s0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_mrcnn50_nm_pf1.16_s0.5/val" \
