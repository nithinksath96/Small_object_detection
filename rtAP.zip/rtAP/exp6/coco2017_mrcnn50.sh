dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=mrcnn50

python det/det_coco.py \
	--data-root "${dataDir}/COCO/val2017" \
	--annot-path "${dataDir}/COCO/annotations/instances_val2017.json" \
	--config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	--weights "${dataDir2}/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--out-dir "${dataDir2}/Exp/COCO/output/${methodName}/val" \
	--eval-mask \
	--overwrite \

	# --vis-dir "${dataDir2}/Exp/COCO/vis/${methodName}/val" \
	# --vis-scale 0.5 \