dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=retina101

python det/det_coco.py \
	--data-root "${dataDir}/COCO/val2017" \
	--annot-path "${dataDir}/COCO/annotations/instances_val2017.json" \
	--config "~/repo/mmdetection/configs/retinanet_r101_fpn_1x.py" \
	--weights "/data/mengtial/ModelZoo/mmdet/retinanet_r101_fpn_2x_20181129-72c14526.pth" \
	--no-mask \
	--out-dir "${dataDir2}/Exp/COCO/output/${methodName}/val" \
	--vis-dir "${dataDir2}/Exp/COCO/vis/${methodName}/val" \
	--vis-scale 0.5 \
	--overwrite \
