dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python forecast/pps_forecast.py \
	--fps 30 \
	--eta 0 \
	--assoc iou \
	--forecast quadratic \
	--forecast-before-assoc \
	--vis-scale 0.5 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--in-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/srt_mrcnn50_nm_ds_s0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/pps_mrcnn50_nm_ds_s0.5_fba_iou_quad/val" \
	--overwrite \

	# --vis-dir "$dataDir/Exp/ArgoVerse1.1/vis/pps_mrcnn50_nm_ds_s0.5_2_fba_iou_lin/val" \

	
