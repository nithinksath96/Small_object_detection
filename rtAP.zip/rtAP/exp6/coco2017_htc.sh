dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=htc_dconv2_ms

python det/det_coco.py \
	--data-root "${dataDir}/COCO/val2017" \
	--annot-path "${dataDir}/COCO/annotations/instances_val2017.json" \
	--config "~/repo/mmdetection/configs/htc/htc_dconv_c3-c5_mstrain_400_1400_x101_64x4d_fpn_20e.py" \
	--weights "$dataDir2/ModelZoo/mmdet/htc_dconv_c3-c5_mstrain_400_1400_x101_64x4d_fpn_20e_20190408-0e50669c.pth" \
	--out-dir "${dataDir2}/Exp/COCO/output/${methodName}/val" \
	--vis-scale 0.5 \
	--eval-mask \
	--overwrite \

	# --vis-dir "${dataDir2}/Exp/COCO/vis/${methodName}/val" \