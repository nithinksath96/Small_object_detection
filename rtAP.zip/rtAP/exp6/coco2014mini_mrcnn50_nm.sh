dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=mrcnn50_nm

python det/det_coco.py \
	--data-root "${dataDir}/COCO/val2014" \
	--annot-path "${dataDir}/COCO/annotations/instances_minival2014.json" \
	--config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	--weights "${dataDir2}/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--no-mask \
	--out-dir "${dataDir2}/Exp/COCO/output/${methodName}/minival2014" \
	--overwrite \

	# --vis-dir "${dataDir2}/Exp/COCO/vis/${methodName}/minival2014" \
	# --vis-scale 1 \