dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/srt_det_coco_fmt.py \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--cached-res "$dataDir/Exp/ArgoVerse1.1/output/yolov3ua/val/results_raw.pkl" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-debug/output/srt_yolov3/val" \
	--no-mask \
	--runtime "$dataDir/Exp/ArgoVerse1.1/runtime-zoo/1080ti/retina50_s0.5.pkl" \
	--perf-factor 1.8 \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1-debug/output/srt_yolov3/val" \
