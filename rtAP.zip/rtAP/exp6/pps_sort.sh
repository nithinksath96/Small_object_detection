dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  echo Warning: SSD directory not found!
  ssdDir="$dataDir"
fi

methodName=mrcnn50_nm_ds_s0.5_2

python track/pps_sort.py \
	--data-root "${ssdDir}/ArgoVerse1.1/tracking" \
	--annot-path "${dataDir}/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--fps 30 \
	--in-dir "${dataDir}/Exp/ArgoVerse1.1/output/srt_${methodName}/val" \
	--out-dir "${dataDir}/Exp/ArgoVerse1.1/output/pps_${methodName}_sort3/val" \
	--overwrite \
	--vis-dir "${dataDir}/Exp/ArgoVerse1.1/vis/pps_${methodName}_sort3/val" \
	--vis-scale 0.5 \

