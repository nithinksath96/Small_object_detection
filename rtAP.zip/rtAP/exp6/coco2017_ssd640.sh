dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=ssd640

python det/det_coco.py \
	--data-root "${dataDir}/COCO/val2017" \
	--annot-path "${dataDir}/COCO/annotations/instances_val2017.json" \
	--config "exp6/ssd640_coco.py" \
	--weights "${dataDir2}/ModelZoo/mmdet/ssd512_coco_vgg16_caffe_120e_20181221-d48b0be8.pth" \
	--no-mask \
	--out-dir "${dataDir2}/Exp/COCO/output/${methodName}/val" \
	--overwrite \
