dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=mrcnn50_nm

python tools/test.py \
	"~/code/rtAP/exp6/mask_rcnn_r50_fpn_1x.py" \
	"${dataDir2}/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--out "${dataDir2}/Exp/COCO/mmdet-output/${methodName}/val/t.pkl" \
	--eval bbox \

	# --json_out "${dataDir2}/Exp/COCO/mmdet-output/${methodName}/val/tt" \

	# --vis-dir "${dataDir2}/Exp/COCO/vis/${methodName}/val" \
	# --vis-scale 0.5 \