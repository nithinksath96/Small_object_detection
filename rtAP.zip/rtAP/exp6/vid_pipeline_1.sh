dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ModelZoo/mmdet" ]; then
  ssdDir="$dataDir"
fi

dbName="WIN_20200221_14_58_26_Pro"
vidPath="$dataDir/Captures/WIN_20200221_14_58_26_Pro.mp4"
vidDBDir="$dataDir/Captures/WIN_20200221_14_58_26_Pro"
config="$HOME/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py"
weights="$ssdDir/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth"
fps=30

imgFolder="$vidDBDir/frames"

# mkdir -p "$imgFolder"
# ffmpeg -i "$vidPath" -qscale:v 2 "$imgFolder/%06d.jpg"

# # Verify FPS
# fps=`ffmpeg -i "$vidPath" 2>&1 | sed -n "s/.*, \(.*\) fp.*/\1/p"`
# echo FPS (ffmpeg): $fps


# python dbcode/db_from_img_folder.py \
# 	--img-folder "$imgFolder" \
# 	--prefix "frames" \
# 	--out-path "$vidDBDir/db.json" \
# 	--overwrite \
# 	&&
# python det/rt_det_coco_fmt.py \
# 	--no-mask \
# 	--fps $fps \
# 	--overwrite \
# 	--dynamic-schedule \
# 	--data-root "$vidDBDir" \
# 	--annot-path "$vidDBDir/db.json" \
# 	--config "$config" \
# 	--weights "$weights" \
# 	--in-scale 0.5 \
# 	--out-dir "$dataDir/Exp/$dbName/output/rt_mrcnn50_nm_ds_s0.5/" \
# 	&&
python forecast/pps_forecast.py \
	--fps $fps \
	--eta 0 \
	--assoc iou \
	--forecast linear \
	--forecast-before-assoc \
	--overwrite \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--in-dir "$dataDir/Exp/$dbName/output/rt_mrcnn50_nm_ds_s0.5/" \
	--out-dir "$dataDir/Exp/$dbName/output/rt_mrcnn50_nm_ds_s0.5_fba_iou_lin/" \
	--no-eval \
	&&
python det/filter_pickup_truck.py \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--in-dir "$dataDir/Exp/$dbName/output/rt_mrcnn50_nm_ds_s0.5_fba_iou_lin/" \
	--out-dir "$dataDir/Exp/$dbName/output/rt_mrcnn50_nm_ds_s0.5_fba_iou_lin_pkt/" \
	--overwrite \
	--no-eval \
	&&
python vis/vis_det_fancy.py \
	--fps $fps \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--result-path "$dataDir/Exp/$dbName/output/rt_mrcnn50_nm_ds_s0.5_fba_iou_lin_pkt/results_ccf.pkl" \
	--vis-dir "$dataDir/Exp/$dbName/visf/rt_mrcnn50_nm_ds_s0.5_fba_iou_lin_pkt/" \
	--overwrite \

echo $dataDir/Exp/$dbName/visf/rt_mrcnn50_nm_ds_s0.5_fba_iou_lin_pkt/
