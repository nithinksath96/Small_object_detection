dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python forecast/mp_det_kf.py \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--fps 30 \
	--eta 0 \
	--config "$HOME/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	--weights "$ssdDir/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--in-scale 0.5 \
	--no-mask \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/mp_mrcnn50_nm_ds_s0.5_2_kf_1/val" \
	--overwrite \
	--dynamic-schedule \
	--runtime "$dataDir/Exp/ArgoVerse1.1/runtime-zoo/1080ti/mrcnn50_nm_s0.5.pkl" \
	--forecast-rt-ub 0.003 \
	&&
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1/output/mp_mrcnn50_nm_ds_s0.5_2_kf_1/val" \




	
