dataDir="/data2/mengtial"

methodName=yolov3_s0.5


python vis/vis_det_fancy.py \
	--data-root "${dataDir}/ArgoVerse1.1/tracking" \
	--annot-path "${dataDir}/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-path "${dataDir}/Exp/ArgoVerse1.1/output/${methodName}/val/results_ccf.pkl" \
	--vis-dir "${dataDir}/Exp/ArgoVerse1.1/visf-th0.5/${methodName}/val" \
	--score-th 0.5 \
	--overwrite \

