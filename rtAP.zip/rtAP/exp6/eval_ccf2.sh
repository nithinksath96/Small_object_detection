dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/eval_coco_fmt.py \
	--annot-path "/data/mengtial/COCO/annotations/instances_val2017.json" \
	--result-path "$dataDir/Exp/COCO/output/mrcnn50/val/results_ccf.pkl" \
	--out-dir "$dataDir/Exp/COCO/output/mrcnn50/val/" \
	--eval-mask \
	--overwrite \
