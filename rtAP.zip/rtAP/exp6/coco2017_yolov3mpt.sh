dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

methodName=yolov3mpt

python det/det_coco.py \
	--data-root "${dataDir}/COCO/val2017" \
	--annot-path "${dataDir}/COCO/annotations/instances_val2017.json" \
	--config "det/yolo_v3/yolov3.py" \
	--weights "${dataDir2}/ModelZoo/yolo/yolov3.weights" \
	--no-mask \
	--out-dir "${dataDir2}/Exp/COCO/output/${methodName}/val" \
	--overwrite \
	# --vis-dir "${dataDir2}/Exp/COCO/vis/${methodName}/val" \
	# --vis-scale 1 \

