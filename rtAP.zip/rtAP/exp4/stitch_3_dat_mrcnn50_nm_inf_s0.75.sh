dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python forecast/stitch_ccf.py \
	--interval 3 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--in-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/pps_dat_mrcnn50_nm_inf_s0.75" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/pps_dat_mrcnn50_nm_inf_s0.75_3_stitched/val" \
