dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python track/srt_dat_inf.py \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--config "$HOME/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	--weights "$ssdDir/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-debug2/output/srti_dat_mrcnn50_nm_s0.5/val" \
	--det1-in-scale 0.5 \
	--det2-in-scale 0.5 \
	--det1-runtime "$dataDir/Exp/ArgoVerse1.1-c3-eta0/runtime-zoo/1080ti/mrcnn50_nm_s0.5.pkl" \
	--det2-runtime "$dataDir/Exp/ArgoVerse1.1-c3-eta0/runtime-zoo/1080ti/dat_track_mrcnn50_nm_s0.5.pkl" \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1-debug2/output/srti_dat_mrcnn50_nm_s0.5/val" \
