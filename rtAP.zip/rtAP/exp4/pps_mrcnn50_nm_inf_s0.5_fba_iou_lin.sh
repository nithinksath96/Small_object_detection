dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse/tracking" ]; then
  ssdDir="$dataDir"
fi


# if [ -f "$dataDir/Exp/ArgoVerse-pgt/output/pps_mrcnn50_nm_inf_s0.5_fba_iou_lin/val/results_ccf.pkl" ]; then
#   echo "Found results for pps_fore-pps_mrcnn50_nm_inf_s0.5_fba_iou_lin, continue" 
#   exit 0 
# fi

python forecast/pps_forecast.py \
	--fps 30 \
	--eta -1 \
	--assoc iou \
	--forecast linear \
	--forecast-before-assoc \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse/tracking" \
	--annot-path "$dataDir/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--in-dir "$dataDir/Exp/ArgoVerse-pgt/output/srt_mrcnn50_nm_inf_s0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse-pgt/output/pps_mrcnn50_nm_inf_s0.5_fba_iou_lin/val" \
