dataDir="/data2/mengtial"

methodA=rt_mrcnn101_nm_cpupre_s1
methodB=rt_mrcnn50_nm_s0.5
dataCfg=ArgoVerse1.1-pgt-c4


python vis/vis_contrast.py \
	--dir-A "${dataDir}/Exp/${dataCfg}/visf/${methodA}/val" \
	--dir-B "${dataDir}/Exp/${dataCfg}/visf/${methodB}/val" \
	--out-dir "${dataDir}/Exp/${dataCfg}/visf/${methodA}-vs-${methodB}/val" \
	--overwrite \
	--make-video \
	--seq b1ca08f1-24b0-3c39-ba4e-d5a92868462c \
	--horizontal \
	--split-pos 0.55 \
	--split-animation swing \

	# --seq 5ab2697b-6e3e-3454-a36a-aba2c6f27818 \


