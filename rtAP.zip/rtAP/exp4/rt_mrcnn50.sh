dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/rt_det_coco_fmt.py \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--config "$HOME/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	--weights "$ssdDir/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--in-scale 0.5 \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/rt_mrcnn50_s0.5/val" \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/rt_mrcnn50_s0.5/val" \
	--vis-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/vis/rt_mrcnn50_s0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/rt_mrcnn50_s0.5/val" \
