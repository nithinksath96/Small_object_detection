dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/det_coco_fmt.py \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--config "$HOME/repo/mmdetection/configs/retinanet_r50_fpn_1x.py" \
	--weights "$ssdDir/ModelZoo/mmdet/retinanet_r50_fpn_2x_20190616-75574209.pth" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-debug/output/retina50_s0.2/val" \
	--in-scale 0.2 \
