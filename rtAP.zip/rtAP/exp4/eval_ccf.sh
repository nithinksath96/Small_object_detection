dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/eval_coco_fmt.py \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--result-path "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/rt_dat_mrcnn50_nm_d15_s0.5/val/results_ccf.pkl" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/rt_dat_mrcnn50_nm_d15_s0.5/val" \
	--overwrite \