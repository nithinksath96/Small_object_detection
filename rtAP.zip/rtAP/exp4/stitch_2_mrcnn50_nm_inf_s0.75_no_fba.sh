dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python forecast/stitch_ccf.py \
	--interval 2 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--in-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/pps_mrcnn50_nm_inf_s0.75_no_fba" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/pps_mrcnn50_nm_inf_s0.75_no_fba_2_stitched/val" \
