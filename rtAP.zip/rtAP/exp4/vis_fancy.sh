dataDir="/data2/mengtial"

methodName=rt_mrcnn50_nm_s0.5

echo ${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json
echo ${dataDir}/Exp/ArgoVerse-pgt-gpupre/output/${methodName}/val/results_ccf.pkl

python vis/vis_det_fancy.py \
	--data-root "${dataDir}/ArgoVerse/tracking" \
	--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--result-path "${dataDir}/Exp/ArgoVerse-pgt-gpupre/output/${methodName}/val/results_ccf.pkl" \
	--vis-dir "${dataDir}/Exp/ArgoVerse-pgt-gpupre/vis/${methodName}/val" \
	--seq f1008c18-e76e-3c24-adcc-da9858fac145 \
	--overwrite \

