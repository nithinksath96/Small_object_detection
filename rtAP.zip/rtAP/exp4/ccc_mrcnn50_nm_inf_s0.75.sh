dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python util/count_concurrent.py \
	--fps 30 \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1-c3-eta0/output/srt_mrcnn50_nm_inf_s0.75/val" \
