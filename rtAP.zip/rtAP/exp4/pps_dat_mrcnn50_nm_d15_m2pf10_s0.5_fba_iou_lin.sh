dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python forecast/pps_forecast.py \
	--fps 30 \
	--eta -1 \
	--assoc iou \
	--forecast linear \
	--forecast-before-assoc \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/htc_dconv2_ms_val_c1.json" \
	--in-dir "$dataDir/Exp/ArgoVerse1.1-pgt-c1/output/srt_dat_mrcnn50_nm_d15_m2pf10_s0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-pgt-c1/output/pps_dat_mrcnn50_nm_d15_m2pf10_s0.5_fba_iou_lin/val" \
