dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python vis/vis_det_fancy.py \
    --vis-scale 1 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--vis-dir "$dataDir/ArgoVerse1.1/tracking/coco_fmt/visf/val_c3" \
	--gt \
	--overwrite \
