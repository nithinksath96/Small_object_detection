dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse/tracking" ]; then
  ssdDir="$dataDir"
fi


# if [ -f "$dataDir/Exp/ArgoVerse-pgt/output/srt_dat_mrcnn50_nm_d15_m2pf1.67_s0.5/val/results_ccf.pkl" ]; then
#   echo "Found results for srt_dat-srt_dat_mrcnn50_nm_d15_m2pf1.67_s0.5, continue" 
#   exit 0 
# fi

python track/srt_det_as_track.py \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse/tracking" \
	--annot-path "$dataDir/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--config "$HOME/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	--weights "$ssdDir/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--out-dir "$dataDir/Exp/ArgoVerse-pgt/output/srt_dat_mrcnn50_nm_d15_m2pf1.67_s0.5/val" \
	--det1-in-scale 0.5 \
	--det2-in-scale 0.5 \
	--track-only \
	--det1-stride 15 \
	--det1-runtime "$dataDir/Exp/ArgoVerse-pgt/runtime-zoo/1080ti/mrcnn50_nm_s0.5.pkl" \
	--det2-runtime "$dataDir/Exp/ArgoVerse-pgt/runtime-zoo/1080ti/dat_track_mrcnn50_nm_s0.5.pkl" \
	--det2-perf-factor 1.67 \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta -1 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse/tracking" \
	--annot-path "$dataDir/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse-pgt/output/srt_dat_mrcnn50_nm_d15_m2pf1.67_s0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse-pgt/output/srt_dat_mrcnn50_nm_d15_m2pf1.67_s0.5/val" \
