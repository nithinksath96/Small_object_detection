dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse/tracking" ]; then
  ssdDir="$dataDir"
fi


# if [ -f "$dataDir/Exp/ArgoVerse-pgt/output/srt_mrcnn50_nm_inf_s0.5/val/results_ccf.pkl" ]; then
#   echo "Found results for srt_det_inf-srt_mrcnn50_nm_inf_s0.5, continue" 
#   exit 0 
# fi

python det/srt_det_inf.py \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse/tracking" \
	--annot-path "$dataDir/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--config "$HOME/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	--weights "$ssdDir/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--out-dir "$dataDir/Exp/ArgoVerse-pgt/output/srt_mrcnn50_nm_inf_s0.5/val" \
	--in-scale 0.5 \
	--no-mask \
	--runtime "$dataDir/Exp/ArgoVerse-pgt/runtime-zoo/1080ti/mrcnn50_nm_s0.5.pkl" \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta -1 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse/tracking" \
	--annot-path "$dataDir/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse-pgt/output/srt_mrcnn50_nm_inf_s0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse-pgt/output/srt_mrcnn50_nm_inf_s0.5/val" \
