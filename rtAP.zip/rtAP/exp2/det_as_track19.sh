dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse/tracking" ]; then
  ssdDir="$dataDir"
fi

methodName=dat_mrcnn50_nm_track_only_s0.5
detStride="15"
# detStride="3"

for d in ${detStride}
do
	python track/det_as_track.py \
		--data-root "${ssdDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	    --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--det1-stride ${d} \
		--det1-in-scale 0.5 \
		--det2-in-scale 0.5 \
		--track-only \
		--out-dir "${dataDir}/Exp/ArgoVerse-pgt/output/${methodName}_d${d}/val" \
		--overwrite \
		--cpu-pre \
		# --vis-dir "${dataDir}/Exp/ArgoVerse-pgt/vis/${methodName}_d${d}/val" \
		# --vis-scale 0.5 \

done