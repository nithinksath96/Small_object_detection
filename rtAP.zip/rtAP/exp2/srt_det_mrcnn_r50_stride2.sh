dataDir="/data2/mengtial"

methodName=mrcnn_r50_nm_sparse_2
scale=0.5
detStride="2"
# detStride="3"

for d in ${detStride}
do
	python det/srt_det_coco_fmt.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	    --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--runtime "${dataDir}/Exp/ArgoVerse/output/rt_mrcnn_r50_no_mask/s${scale}_val/time_all.pkl" \
		--no-mask \
		--in-scale ${scale} \
		--det-stride ${d} \
		--fps 30 \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/srt_${methodName}_d${d}/s${scale}_val" \
		--seed 2 \
		--overwrite \
		&&
	python det/rt_merge_cvt.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--fps 30 \
		--result-dir "${dataDir}/Exp/ArgoVerse/output/srt_${methodName}_d${d}/s${scale}_val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/srt_${methodName}_d${d}/s${scale}_val" \
		--vis-scale 0.5 \
		--overwrite \

done
