sh exp2/rt_det_2cfg_mrcnn_r50.sh
sh exp2/rt_dat_mrcnn_r50.sh
