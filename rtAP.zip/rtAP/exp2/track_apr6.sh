dataDir="/data2/mengtial"

methodName=cv2csrdcf_mrcnn50
detStride="15 30"
s=0.5
# detStride="3"

for d in ${detStride}
do
	python track/track_apr.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--det-ccf-path "${dataDir}/Exp/ArgoVerse/output/mrcnn_r50/s0.5_val/results_ccf.pkl" \
		--det-stride ${d} \
		--in-scale ${s} \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}_s${s}_d${d}/val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/${methodName}_s${s}_d${d}/val" \
		--vis-scale 0.5 \
		--overwrite \

done

