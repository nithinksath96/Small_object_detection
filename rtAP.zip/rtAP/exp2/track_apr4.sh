dataDir="/data2/mengtial"

methodName=cv2csrdcf_mrcnn50_recover
detStride="30"

for d in ${detStride}
do
	python track/track_apr.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--det-ccf-path "${dataDir}/Exp/ArgoVerse/output/mrcnn_r50/s0.5_val/results_ccf.pkl" \
		--det-stride ${d} \
		--fail-recover \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}_d${d}/s1_val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/${methodName}_d${d}/s1_val" \
		--vis-scale 0.5 \
		--overwrite \

done