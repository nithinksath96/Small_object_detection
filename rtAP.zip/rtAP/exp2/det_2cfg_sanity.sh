dataDir="/data2/mengtial"

methodName=mrcnn_r50_nm_2cfg_sanity
det1Stride="30"

for d in ${det1Stride}
do
	python det/det_2cfg.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	    --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--det1-stride ${d} \
		--det1-in-scale 0.5 \
		--det2-in-scale 0.5 \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}_d${d}/val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/${methodName}_d${d}/val" \
		--vis-scale 0.5 \
		--overwrite \

done
