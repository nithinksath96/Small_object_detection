sh exp2/det_2cfg_mrcnn_r50.sh
sh exp2/det_as_track4.sh

