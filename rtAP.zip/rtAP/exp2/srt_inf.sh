dataDir="/data2/mengtial"

methodName=mrcnn_r50_nm
scales="0.25 0.5 0.75 1"

for s in ${scales}
do
	python det/srt_inf.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--det-ccf-path "${dataDir}/Exp/ArgoVerse/output/mrcnn_r50/s${s}_val/results_ccf.pkl" \
		--runtime "${dataDir}/Exp/ArgoVerse/output/rt_mrcnn_r50_no_mask/s${s}_val/time_all.pkl" \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/srt_inf_${methodName}/s${s}_val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/srt_inf_${methodName}/s${s}_val" \
		--vis-scale 0.5 \
		--overwrite \

done