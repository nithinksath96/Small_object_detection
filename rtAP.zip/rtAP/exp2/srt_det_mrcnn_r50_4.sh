dataDir="/data2/mengtial"

methodName=mrcnn_r50_no_mask
scales="1"
i=4

for s in ${scales}
do
	python det/srt_det_coco_fmt.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	    --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--runtime "${dataDir}/Exp/ArgoVerse/runtime-zoo/1080ti/${methodName}_3_s1.pkl" \
		--no-mask \
		--in-scale ${s} \
		--fps 30 \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/srt_${methodName}_${i}/s${s}_val" \
		--overwrite \
		--seed ${i} \
		&&
	python det/rt_merge_cvt.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--fps 30 \
		--result-dir "${dataDir}/Exp/ArgoVerse/output/srt_${methodName}_${i}/s${s}_val" \
		--overwrite \

done
