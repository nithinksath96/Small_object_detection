dataDir="/data2/mengtial"

methodName=dat_mrcnn50_nm_plus_det_no_kill
detStride="30"
# detStride="3"

for d in ${detStride}
do
	python track/det_as_track2.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	    --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--det1-stride ${d} \
		--det1-in-scale 0.5 \
		--det2-in-scale 0.5 \
		--no-kill \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}_d${d}/val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/${methodName}_d${d}/val" \
		--vis-scale 0.5 \
		--overwrite \

done