dataDir="/data2/mengtial"

methodName=dat_mrcnn50_nm_track_only_s0.5_s0.25
# detStride="2"
detStride="3 15 30"

for d in ${detStride}
do
	# python track/rt_det_as_track.py \
	# 	--data-root "${dataDir}/ArgoVerse/tracking" \
	# 	--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
	#     --config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	# 	--weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	# 	--track-only \
	# 	--det1-stride ${d} \
	# 	--det1-in-scale 0.5 \
	# 	--det2-in-scale 0.25 \
	# 	--out-dir "${dataDir}/Exp/ArgoVerse/output/rt_${methodName}_d${d}/val" \
	# 	--overwrite \
	# 	&&
	python det/rt_merge.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--fps 30 \
		--result-dir "${dataDir}/Exp/ArgoVerse/output/rt_${methodName}_d${d}/val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/rt_${methodName}_d${d}/val" \
		--vis-scale 0.5 \
		--overwrite \
		
done