dataDir="/data2/mengtial"

methodName=cv2csrdcf_s1_mrcnn50_nm_s0.5
detStride="2"
# detStride="3 15 30"


for d in ${detStride}
do
	python track/srt_track_apr.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--fps 30 \
		--det-stride ${d} \
		--det-in-scale 0.5 \
	    --det-config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
		--det-weights "/data/mengtial/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
		--det-runtime "${dataDir}/Exp/ArgoVerse/output/rt_mrcnn_r50_no_mask/s0.5_val/time_all.pkl" \
		--tracker cv2.CSRT \
		--tracker-runtime "${dataDir}/Exp/ArgoVerse/output/cv2csrdcf_mrcnn50_d10/s1_val/time_tracker.pkl" \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/srt_${methodName}_d${d}/val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/srt_${methodName}_d${d}/val" \
		--vis-scale 0.5 \
		--overwrite \

done