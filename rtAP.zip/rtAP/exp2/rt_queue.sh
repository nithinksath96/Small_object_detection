sh exp2/track_apr5.sh



