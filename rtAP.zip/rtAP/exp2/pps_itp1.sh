dataDir="/data2/mengtial"

methodName=rt_dat_mrcnn50_nm_track_only_s0.5
detStride="2 3 15 30"

for d in ${detStride}
do
	python track/pps_iou_lin_extrap.py \
		--data-root "${dataDir}/ArgoVerse/tracking" \
		--annot-path "${dataDir}/ArgoVerse/tracking/coco_fmt/htc_dconv2_ms_val.json" \
		--fps 30 \
		--max-det 100 \
		--result-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}_d${d}/val" \
		--out-dir "${dataDir}/Exp/ArgoVerse/output/${methodName}_d${d}_itp/val" \
		--vis-dir "${dataDir}/Exp/ArgoVerse/vis/${methodName}_d${d}_itp/val" \
		--vis-scale 0.5 \
		--overwrite \
		
done