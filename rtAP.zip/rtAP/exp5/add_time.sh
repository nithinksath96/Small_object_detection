dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

python util/add_to_runtime_zoo.py \
	--time-info "${dataDir}/Exp/ArgoVerse1.1-c3-eta0/output/rt_htc_dconv2_ms_cpupre_s1/val/time_info.pkl" \
	--out-path "${dataDir}/Exp/ArgoVerse1.1-c3-eta0/runtime-zoo/1080ti/htc_dconv2_ms_cpupre_s1.pkl" \


