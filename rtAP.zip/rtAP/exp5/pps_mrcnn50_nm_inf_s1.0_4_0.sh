dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python forecast/pps_forecast_sparse.py \
	--interval 4 \
	--index 0 \
	--fps 30 \
	--eta 0 \
	--assoc iou \
	--forecast linear \
	--forecast-before-assoc \
	--vis-scale 0.5 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--in-dir "$dataDir/Exp/ArgoVerse1.1-V100-AWS/output/srt_mrcnn50_nm_inf_s1.0/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1-V100-AWS/output/pps_mrcnn50_nm_inf_s1.0_4_0/val" \
