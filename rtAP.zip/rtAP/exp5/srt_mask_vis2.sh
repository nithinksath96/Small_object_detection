dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

python det/srt_det_coco_fmt.py \
	--fps 30 \
	--overwrite \
	--config "~/repo/mmdetection/configs/mask_rcnn_r50_fpn_1x.py" \
	--weights "${ssdDir}/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_20181010-41d35c05.pth" \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_mrcnn50_vm_ds_s0.75/val" \
	--in-scale 0.75 \
	--runtime "$dataDir/Exp/ArgoVerse1.1-c3-eta0/runtime-zoo/1080ti/mrcnn50_nm_s0.75.pkl" \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_mrcnn50_vm_ds_s0.75/val" \

