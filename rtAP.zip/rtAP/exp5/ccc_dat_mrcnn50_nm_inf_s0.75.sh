dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python util/count_concurrent.py \
	--fps 30 \
	--type dat \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val_c3.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1-debug/output/srt_dat_mrcnn50_nm_inf_s0.75/val" \
