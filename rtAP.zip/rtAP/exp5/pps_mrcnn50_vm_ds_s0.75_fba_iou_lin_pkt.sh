dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/filter_pickup_truck.py \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--in-dir "$dataDir/Exp/ArgoVerse1.1/output/pps_mrcnn50_vm_ds_s0.75_fba_iou_lin/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/pps_mrcnn50_vm_ds_s0.75_fba_iou_lin_pkt/val" \
	--overwrite \
	