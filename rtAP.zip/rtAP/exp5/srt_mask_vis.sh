dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

	# --cached-res "$dataDir/Exp/ArgoVerse1.1-c3/output/htc_dconv2_ms_s1/val/results_raw.pkl" \
# python det/srt_det_coco_fmt.py \
# 	--fps 30 \
# 	--overwrite \
# 	--config "~/repo/mmdetection/configs/htc/htc_dconv_c3-c5_mstrain_400_1400_x101_64x4d_fpn_20e.py" \
# 	--weights "$ssdDir/ModelZoo/mmdet/htc_dconv_c3-c5_mstrain_400_1400_x101_64x4d_fpn_20e_20190408-0e50669c.pth" \
# 	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
# 	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
# 	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_htc_dconv2_ms_vm_s1.0/val" \
# 	--in-scale 1 \
# 	--runtime "$dataDir/Exp/ArgoVerse1.1-c3-eta0/runtime-zoo/1080ti/htc_dconv2_ms_cpupre_s1.pkl" \
#     && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_htc_dconv2_ms_vm_s1.0/val" \

