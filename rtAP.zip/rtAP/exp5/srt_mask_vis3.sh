dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

python det/srt_det_coco_fmt.py \
	--fps 30 \
	--overwrite \
	--config "~/repo/mmdetection/configs/cascade_mask_rcnn_r101_fpn_1x.py" \
	--weights "${ssdDir}/ModelZoo/mmdet/cascade_mask_rcnn_r101_fpn_20e_20181129-cb85151d.pth" \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_cmrcnn101_vm_s1.0/val" \
	--in-scale 1 \
	--runtime "$dataDir/Exp/ArgoVerse1.1/runtime-zoo/1080ti/cmrcnn101_nm_s1.0.pkl" \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_cmrcnn101_vm_s1.0/val" \

