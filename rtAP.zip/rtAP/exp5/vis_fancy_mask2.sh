dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

methodName=srt_htc_dconv2_ms_vm_s1.0


python vis/vis_det_fancy.py \
	--data-root "${ssdDir}/ArgoVerse1.1/tracking" \
	--annot-path "${dataDir}/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-path "${dataDir}/Exp/ArgoVerse1.1/output/${methodName}/val/results_ccf.pkl" \
	--vis-dir "${dataDir}/Exp/ArgoVerse1.1/visf-th0.5/${methodName}/val" \
	--score-th 0.5 \
	--seq 5ab2697b-6e3e-3454-a36a-aba2c6f27818 \
	--overwrite \

	# --seq b1ca08f1-24b0-3c39-ba4e-d5a92868462c \
	# --seq 5ab2697b-6e3e-3454-a36a-aba2c6f27818 \
	# --seq f1008c18-e76e-3c24-adcc-da9858fac145 \