# srt_det_coco_fmt with multiple methods

import argparse, json, pickle
from os.path import join, isfile, basename

from tqdm import tqdm
import numpy as np

import torch

from pycocotools.coco import COCO

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2, print_stats
from util.bbox import ltwh2ltrb_
from util.runtime_dist import dist_from_dict
from det import imread, parse_det_result, result_from_ccf
from det.det_apis import init_detector, inference_detector


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-root', type=str, required=True)
    parser.add_argument('--annot-path', type=str, required=True)
    parser.add_argument('--det-stride', type=float, default=1)
    parser.add_argument('--dynamic-schedule', action='store_true', default=False)
    parser.add_argument('--fps', type=float, default=30)
    parser.add_argument('--no-mask', action='store_true', default=False)
    parser.add_argument('--no-class-mapping', action='store_true', default=False)
    parser.add_argument('--out-dir', type=str, required=True)
    parser.add_argument('--perf-factor', type=float, default=1)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--overwrite', action='store_true', default=False)

    opts = parser.parse_args()
    return opts

def main():
    opts = parse_args()

    #########
    exp_dir = '/data2/mengtial/Exp/'
    caches = [
        join(exp_dir, 'Argoverse-HD/output/mrcnn50_nm_s0.5/val/results_ccf.pkl'),
        join(exp_dir, 'Argoverse-HD/output/mrcnn50_nm_cs_s1.0/val/results_ccf.pkl'),
    ]

    runtimes = [
        join(exp_dir, 'Argoverse-HD/runtime-zoo/1080ti/mrcnn50_nm_s0.5.pkl'),
        join(exp_dir, 'Argoverse-HD/runtime-zoo/1080ti/mrcnn50_nm_cs_s1.0.pkl'),
    ]

    # switch_stride = 2

    #########
    n_method = len(caches)

    cache_ccfs = [pickle.load(open(path, 'rb')) for path in caches]
    cache_end_idx = n_method*[0]
    rt_dists = [
        dist_from_dict(pickle.load(open(path, 'rb')), opts.perf_factor)
        for path in runtimes
    ]
    if opts.dynamic_schedule:
        mean_rtfs = [rtd.mean()*opts.fps for rtd in rt_dists]

    mkdir2(opts.out_dir)

    db = COCO(opts.annot_path)
    class_names = [c['name'] for c in db.dataset['categories']]
    n_class = len(class_names)
    coco_mapping = None if opts.no_class_mapping else db.dataset.get('coco_mapping', None)
    if coco_mapping is not None:
        coco_mapping = np.asarray(coco_mapping)
    seqs = db.dataset['sequences']
    seq_dirs = db.dataset['seq_dirs']


    np.random.seed(opts.seed)

    runtime_all = []
    method_id_all = []
    n_processed = 0
    n_total = 0

    for sid, seq in enumerate(tqdm(seqs)):
        frame_list = [img for img in db.imgs.values() if img['sid'] == sid]
        n_frame = len(frame_list)
        n_total += n_frame

        # load all frames in advance
        frames = []
        for img in frame_list:
            img_path = join(opts.data_root, seq_dirs[sid], img['name'])
            frames.append(imread(img_path))
        
        timestamps = []
        results_parsed = []
        input_fidx = []
        runtime = []
        method_ids = []
        last_fidx = None
        results_raw = None
        
        t_total = n_frame/opts.fps
        t_elapsed = 0
        stride_cnt = 0

        while 1:
            if t_elapsed >= t_total:
                break

            # identify latest available frame
            fidx_continous = t_elapsed*opts.fps
            fidx = int(np.floor(fidx_continous))
            if fidx == last_fidx:
                # algorithm is fast and has some idle time
                fidx += 1
                if fidx == n_frame:
                    break
                t_elapsed = fidx/opts.fps
                
            last_fidx = fidx

            method_id = len(results_parsed) % 2
            if opts.dynamic_schedule:
                if mean_rtfs[not method_id] > 1:
                    # when runtime <= 1, it should always process every frame
                    fidx_remainder = fidx_continous - fidx
                    if mean_rtfs[method_id] < np.floor(fidx_remainder + mean_rtfs[method_id]):
                        # wait till next frame
                        continue
            else:
                if stride_cnt % opts.det_stride == 0:
                    stride_cnt = 1
                else:
                    stride_cnt += 1
                    continue
            
            
            img = frame_list[fidx]
            cache_end_idx[method_id], bboxes, scores, labels, masks = \
                result_from_ccf(cache_ccfs[method_id], img['id'], cache_end_idx[method_id])
            ltwh2ltrb_(bboxes)
            rt_this = rt_dists[method_id].draw()

            t_elapsed += rt_this
            if t_elapsed >= t_total:
                break
            
            timestamps.append(t_elapsed)
            if results_raw is not None:
                results_raw.append(result)
            results_parsed.append((bboxes, scores, labels, masks))
            input_fidx.append(fidx)
            runtime.append(rt_this)
            method_ids.append(method_id)

        out_path = join(opts.out_dir, seq + '.pkl')
        if opts.overwrite or not isfile(out_path):
            out_dict = {
                'results_parsed': results_parsed,
                'timestamps': timestamps,
                'input_fidx': input_fidx,
                'runtime': runtime,
                'method_ids': method_ids,
            }
            if results_raw is not None:
                out_dict['results_raw'] = results_raw
            pickle.dump(out_dict, open(out_path, 'wb'))

        runtime_all += runtime
        n_processed += len(results_parsed)
        method_id_all += method_ids

    runtime_all_np = np.array(runtime_all)
    n_small_runtime = (runtime_all_np < 1.0/opts.fps).sum()

    out_path = join(opts.out_dir, 'time_info.pkl')
    if opts.overwrite or not isfile(out_path):
        pickle.dump({
            'runtime_all': runtime_all,
            'n_processed': n_processed,
            'n_total': n_total,
            'n_small_runtime': n_small_runtime,
            'method_id_all': method_id_all,
        }, open(out_path, 'wb'))  

    # convert to ms for display
    s2ms = lambda x: 1e3*x

    print(f'{n_processed}/{n_total} frames processed')
    print_stats(runtime_all_np, 'Runtime (ms)', cvt=s2ms)
    print(f'Runtime smaller than unit time interval: '
        f'{n_small_runtime}/{n_processed} '
        f'({100.0*n_small_runtime/n_processed:.4g}%)')

if __name__ == '__main__':
    main()