# Set up pseudo ground truth for object detection

from os.path import join

import json
import numpy as np

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import print_stats


db_path = '/data2/mengtial/ArgoVerse1.1/tracking/coco_fmt/val_c3.json'
db = json.load(open(db_path))

annots = db['annotations']
small = 0
medium = 0
large = 0

for annot in annots:
    if annot['area'] <= 32**2*8.417:
        small += 1
    elif annot['area'] <= 96**2*8.417:
        medium += 1
    else:
        large += 1
print(small, medium, large)
total = small + medium + large
print('%.1f%% %.1f%% %.1f%%' % (100*small/total, 100*medium/total, 100*large/total))
