
import json

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import print_stats

db_path = 'D:/Data/ArgoVerse1.1/tracking/coco_fmt/val.json'
db = json.load(open(db_path))

seqs = db['sequences']
d = []
for sid, seq in enumerate(seqs):
    frame_list = [img for img in db['images'] if img['sid'] == sid]
    last = None
    for img in frame_list:
        t = img['name'].split('_')[-1][:-4]
        t = int(t)
        if last is not None:
            d.append(t - last)
        last = t

print_stats(d, fmt='%.6f', cvt=lambda x: x/1e6)
