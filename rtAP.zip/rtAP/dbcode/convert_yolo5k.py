'''
By default yolo trains on 2014 train + val - (yolo 5k) and tested on (yolo 5k)
4320/5000 of the val2017 images are actually in yolo's training set
We should only evaluate pretrained yolo model on yolo 5k

This script converts yolo 5k to standard COCO annotations format
'''

from os.path import basename
import json

val2014 = json.load(open('E:/Data/COCO/annotations/instances_val2014.json'))
yolo5k = open('D:/Downloads/5k.part').read().splitlines()

yolo5k_names = [basename(f) for f in yolo5k]
images = list(filter(lambda img: img['file_name'] in yolo5k_names, val2014['images']))
iids = [img['id'] for img in images]
annots = list(filter(lambda ann: ann['image_id'] in iids, val2014['annotations']))

val2014['images'] = images
val2014['annotations'] = annots

json.dump(val2014, open('E:/Data/COCO/annotations/instances_val2014_yolo5k.json', 'w'))