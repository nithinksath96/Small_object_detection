# Set up pseudo ground truth for object detection
from os import scandir
from os.path import join, isfile
from shutil import copy2

import numpy as np
from tqdm import tqdm
import json, requests, scaleapi

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2


chunk_size = 200
overlap = 3

# scale_key = 'test_8b3713ce60014513900e41c8635cd126'
scale_key = 'live_77de3102d768429d89996f039135e932'
s3_prefix = 'https://achal-public.s3.amazonaws.com/martin/av1.1'
callback_url = 'https://en25b892btqow.x.pipedream.net'
instruction = '<iframe src="https://docs.google.com/document/d/e/2PACX-1vSXir32p8Va9jr0NsVsjXVzfg5IKFMlPP6o6LbCoSWisouGvHdldIfRUJFJZcIeWrHk0MMvIjFtJ5Qh/pub?embedded=true"></iframe>'
# project = 'Carnegie Mellon University_default_videoboxannotation'
project = 'Martin Efficiency Benchmark'


data_dir = 'D:/Data'

data_root = join(data_dir, 'ArgoVerse1.1', 'tracking')
view = 'ring_front_center'

split = 'val'
total_images_verification = 15062

out_dir = mkdir2(join(data_dir, 'ArgoVerse1.1', 'annot_scale', 'tracking_val'))

seqs_dir = join(data_root, split)
seqs = sorted([item.name for item in scandir(seqs_dir) if item.is_dir()])
seq_dirs = [split + '/' + seq + '/' + view for seq in seqs]


annot_classes = [
    'person',
    'bicycle',
    'motorcycle',
    'car',
    'pickup_truck',
    'truck',
    'bus',
    'traffic_light',
    'stop_sign',
    'fire_hydrant',
]

attributes = {
    'is_crowd': {
        'type': 'category',
        'description': 'Is this a group of objects of the SAME CLASS that each instance CANNOT be identified?',
        'choices': ['True', 'False'],
    }
}


client = scaleapi.ScaleClient(scale_key)


def upload_bbox_task(image_urls, categories, attributes, scale_key, callback_url,
                     instruction, project):
    payload = {
        'callback_url': callback_url,
        'project': project,
        'instruction': instruction,
        'attachment_type': 'image',
        'attachments': image_urls,
        'objects_to_annotate': categories,
        'annotation_attributes': attributes,
        'with_labels': True,
    }

    headers = {"Content-Type": "application/json"}

    task_request = requests.post(
        "https://api.scale.com/v1/task/videoboxannotation",
        json=payload,
        headers=headers,
        auth=(scale_key, ''))

    return task_request


task_ids = []
task_sids = []
task_seqs = []
task_i_starts = []
task_i_ends = []
task_i_lens = []

n_img = 0
for sid, seq in enumerate(tqdm(seqs)):
    seq_imgs = sorted(
        [item.name for item in scandir(join(data_root, seq_dirs[sid]))
            if item.is_file()])
    n = len(seq_imgs)
    i_start = 0
    while i_start < n:
        i_end = min(i_start + chunk_size, n)

        task_sids.append(sid)
        task_seqs.append(seq)
        task_i_starts.append(i_start)
        task_i_ends.append(i_end)
        task_i_lens.append(i_end - i_start)
        image_urls = [f'{s3_prefix}/{view}/{seq}/{name}' for name in seq_imgs[i_start:i_end]]
        
        reponse = upload_bbox_task(image_urls, annot_classes, attributes,
            scale_key, callback_url, instruction, project)
        r = reponse.json()
        assert r['status'] == 'pending' or r['status'] == 'completed'
        assert len(r['params']['attachments']) == len(image_urls), r

        n_img += len(image_urls)
        task_ids.append(r['task_id'])
        # task_ids.append([])

        i_start += chunk_size - overlap



print('Total number of images:', n_img)
assert n_img >= total_images_verification

task_info = {
    'task_ids': task_ids,
    'task_sids': task_sids,
    'task_seqs': task_seqs,
    'task_i_starts': task_i_starts,
    'task_i_ends': task_i_ends,
    'task_i_lens': task_i_lens,
}

with open(join(out_dir, 'task_info_chunk.json'), 'w', encoding='utf-8') as f:
    json.dump(task_info, f, indent=4)

