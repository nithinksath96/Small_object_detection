# Set up pseudo ground truth for object detection
from os import scandir
from os.path import join, isfile
from shutil import copy2

import numpy as np
from tqdm import tqdm
import json, requests, scaleapi

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2


data_dir = 'D:/Data'
in_path = join(data_dir, 'ArgoVerse1.1', 'annot_scale', 'tracking_val', 'task_seq.json')
task_seq = json.load(open(in_path))
task_ids = task_seq['task_ids']

# scale_key = 'test_8b3713ce60014513900e41c8635cd126'
scale_key = 'live_77de3102d768429d89996f039135e932'

client = scaleapi.ScaleClient(scale_key)


# task_ids = [
#     '5da7a9a7f3c7b322d5199f76',
# ]


for task_id in task_ids:
    try:
        task = client.cancel_task(task_id)
    except Exception as e:
        print(e)
    print(task)
    


