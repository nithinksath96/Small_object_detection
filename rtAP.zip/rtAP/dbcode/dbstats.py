# Set up pseudo ground truth for object detection

from os.path import join

import json
import numpy as np


import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')


data_dir = 'D:/Data'
data_root = join(data_dir, 'ArgoVerse1.1', 'tracking')
db_path = join(data_root, 'coco_fmt', 'htc_dconv2_ms_val_c3.json')

db = json.load(open(db_path))

cats = db['categories']
annots = db['annotations']
n_class = len(cats)

all_class = [a['category_id'] for a in annots]
class_cnt = np.histogram(all_class, n_class)[0]
assert class_cnt[n_class - 1] == (np.array(all_class) == n_class - 1).sum()

for i, c in enumerate(cats):
    print(f'{i+1} {c["name"]}: {class_cnt[i]}')
