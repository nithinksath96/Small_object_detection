# copy the minimal data needed

from os import scandir
from os.path import join
from shutil import copytree

from tqdm import tqdm

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2

src_dir = '/data2/mengtial'
dst_dir = '/scratch/mengtial'

src_root = join(src_dir, 'ArgoVerse1.1', 'tracking')
dst_root = mkdir2(join(dst_dir, 'ArgoVerse1.1', 'tracking'))

view = 'ring_front_center'
split = 'val'

seqs_dir = join(src_root, split)
seqs = sorted([item.name for item in scandir(seqs_dir) if item.is_dir()])
seq_dirs = [split + '/' + seq + '/' + view for seq in seqs]

for sid, seq in enumerate(tqdm(seqs)):
    copytree(join(src_root, seq_dirs[sid]), join(dst_root, seq_dirs[sid]))
