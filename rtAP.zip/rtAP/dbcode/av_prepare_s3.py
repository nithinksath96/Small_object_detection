# Set up pseudo ground truth for object detection
from os import scandir
from os.path import join, isfile
from shutil import copy2

import numpy as np
from tqdm import tqdm

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2
from dbcode.dbinfo import av_classes, coco2av

data_dir = 'D:/Data'

data_root = join(data_dir, 'ArgoVerse1.1', 'tracking')
view = 'ring_front_center'

img_width, img_height = 1920, 1200
split = 'val'

out_dir = mkdir2(join(data_dir, 'ArgoVerse1.1', 's3_annot', view))

seqs_dir = join(data_root, split)
seqs = sorted([item.name for item in scandir(seqs_dir) if item.is_dir()])
seq_dirs = [split + '/' + seq + '/' + view for seq in seqs]

iid = 0
imgs = []


for sid, seq in enumerate(tqdm(seqs)):
    seq_imgs = sorted(
        [item.name for item in scandir(join(data_root, seq_dirs[sid]))
            if item.is_file()])
    out_dir_seq = mkdir2(join(out_dir, seq))
    for fid, name in enumerate(seq_imgs):
        in_path = join(data_root, seq_dirs[sid], name)
        out_path = join(out_dir_seq, name)
        copy2(in_path, out_path)

        iid += 1

print(iid)