# Converting instance segmentation to COCO style bbox + mask

from os import scandir
from os.path import join, isfile

import json, random
import numpy as np
from tqdm import tqdm

import pycocotools.mask as maskUtils

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2
from dbcode.dbinfo import kmots_classes, coco2av

data_dir = 'D:/Data'
data_root = join(data_dir, 'KMOTS')

img_width, img_height = 1242, 375
seqs_dir = join(data_root, 'original/training/image_02')
annot_dir = join(data_root, 'original/instances_txt')

out_dir = mkdir2(join(data_root, 'coco_fmt'))
out_name = 'custom_split_val.json'

seqs = sorted([item.name for item in scandir(seqs_dir) if item.is_dir()])

# use 7 sequences as the validation set
random.seed(0)
val_seqs = random.sample(seqs, 7)

# use only val for now
seqs = val_seqs
seq_dirs = [seqs_dir + '/' + seq for seq in seqs]

iid = 0
aid = 0
imgs = []
annots = []

cats = []
for i, c in enumerate(kmots_classes):
    cats.append({'id': i, 'name': c})

def load_txt(path):
    # modified from https://github.com/VisualComputingInstitute/mots_tools/blob/master/mots_common/io.py
    objects_per_frame = {}
    track_ids_per_frame = {}  # To check that no frame contains two objects with same id
    combined_mask_per_frame = {}  # To check that no frame contains overlapping masks
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            fields = line.split(" ")

            class_id = int(fields[2])
            if not(class_id == 1 or class_id == 2 or class_id == 10):
                assert False, "Unknown object class " + fields[2]
            if class_id == 10:
                continue

            frame = int(fields[0])
            if frame not in objects_per_frame:
                objects_per_frame[frame] = []
            if frame not in track_ids_per_frame:
                track_ids_per_frame[frame] = set()
            if int(fields[1]) in track_ids_per_frame[frame]:
                assert False, "Multiple objects with track id " + fields[1] + " in frame " + fields[0]
            else:
                track_ids_per_frame[frame].add(int(fields[1]))

            mask = {'size': [int(fields[3]), int(fields[4])], 'counts': fields[5]} # fields[5].encode(encoding='UTF-8')
            if frame not in combined_mask_per_frame:
                combined_mask_per_frame[frame] = mask
            elif maskUtils.area(maskUtils.merge([combined_mask_per_frame[frame], mask], intersect=True)) > 0.0:
                assert False, "Objects with overlapping masks in frame " + fields[0]
            else:
                combined_mask_per_frame[frame] = maskUtils.merge([combined_mask_per_frame[frame], mask], intersect=False)
            objects_per_frame[frame].append((
                mask,
                class_id,
                int(fields[1])
            ))

    return objects_per_frame

for sid, seq in enumerate(tqdm(seqs)):
    org_annots = load_txt(join(annot_dir, seq + '.txt'))
    fid = 0 # frame id
    seq_imgs = sorted(
        [item.name for item in scandir(join(data_root, seq_dirs[sid]))
            if item.is_file()])
    for fid, name in enumerate(seq_imgs):
        if fid in org_annots:
            for obj in org_annots[fid]:
                annots.append({
                    'id': aid,
                    'image_id': iid,
                    'bbox': maskUtils.toBbox(obj[0]).tolist(),
                    'category_id': obj[1] - 1,
                    'segmentation': obj[0],
                    'area': float(maskUtils.area(obj[0])),
                    'iscrowd': False,
                    'ignore': False,
                })

                aid += 1

        imgs.append({
            'id': iid,
            'sid': sid,
            'fid': fid,
            'name': name,
            'width': img_width,
            'height': img_height,
        })

        iid += 1

dataset = {
    'categories': cats,
    'images': imgs,
    'annotations': annots,
    'sequences': seqs,
    'seq_dirs': seq_dirs,
}

json.dump(dataset, open(join(out_dir, out_name), 'w'))
