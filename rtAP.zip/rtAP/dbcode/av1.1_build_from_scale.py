# Set up pseudo ground truth for object detection

from os import scandir
from os.path import join, isfile

import json, pickle
from tqdm import tqdm

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2
from dbcode.dbinfo import *

data_dir = 'D:/Data'
data_root = join(data_dir, 'ArgoVerse1.1', 'tracking')
class_subset = acc_subset_3

view = 'ring_front_center'
img_width, img_height = 1920, 1200
split = 'val'

in_dir = join(data_dir, 'ArgoVerse1.1', 'annot_scale', 'tracking_val')

out_dir = mkdir2(join(data_root, 'coco_fmt'))
out_name = split + '.json'

seqs_dir = join(data_root, split)
seqs = sorted([item.name for item in scandir(seqs_dir) if item.is_dir()])
seq_dirs = [split + '/' + seq + '/' + view for seq in seqs]

iid = 0
aid = 0
imgs = []
annots = []

cats = []
class_names = []
for i, c in enumerate(class_subset):
    cats.append({'id': i, 'name': coco_classes[c]})
    class_names.append(coco_classes[c])

n_class = len(cats)

task_info = json.load(open(join(in_dir, 'task_info_chunk.json')))
task_ids = task_info['task_ids']
task_sids = task_info['task_sids']
task_seqs = task_info['task_seqs']
task_i_starts = task_info['task_i_starts']
task_i_ends = task_info['task_i_ends']
task_i_lens = task_info['task_i_lens']
n_task = len(task_ids)

labels_ignored = []
for sid, seq in enumerate(tqdm(seqs)):
    fid = 0 # frame id
    seq_imgs = sorted(
        [item.name for item in scandir(join(data_root, seq_dirs[sid]))
            if item.is_file()])
    tasks = [i for i in range(n_task) if task_sids[i] == sid]
    task_annot = []
    for t in tasks:
        raw_annot = json.load(open(join(in_dir, 'raw_annot', task_ids[t] + '.json')))
        task_annot.append(raw_annot)
    task_idx = 0
    for fid, name in enumerate(seq_imgs):
        if fid >= task_i_ends[tasks[task_idx]]:
            task_idx += 1
        fid_in_task = fid - task_i_starts[tasks[task_idx]]
        annot_frame = task_annot[task_idx][fid_in_task]['annotations']

        for obj in annot_frame:
            label = obj['label']
            if label == 'pickup_truck':
                # map pickup truck to truck as defined in COCO
                label = 'truck'
            if label in class_names:
                label = class_names.index(label)
            else:
                if label not in labels_ignored:
                    labels_ignored.append(label)
                continue

            bbox = [obj['left'], obj['top'], obj['width'], obj['height']]
            iscrowd = obj['attributes']['is_crowd'] == 'True'

            annots.append({
                'id': aid,
                'image_id': iid,
                'bbox': bbox,
                'category_id': label,
                'area': float(bbox[2]*bbox[3]),
                'iscrowd': iscrowd,
                'ignore': False,
            })

            aid += 1

        imgs.append({
            'id': iid,
            'sid': sid,
            'fid': fid,
            'name': name,
            'width': img_width,
            'height': img_height,
        })

        iid += 1

print('labels ignored:', labels_ignored)

n_coco = len(coco_classes)
coco_mapping = n_coco*[n_coco]
for i, c in enumerate(class_subset):
    coco_mapping[c] = i

dataset = {
    'categories': cats,
    'images': imgs,
    'annotations': annots,
    'sequences': seqs,
    'seq_dirs': seq_dirs,
    'coco_subset': class_subset,
    'coco_mapping': coco_mapping,
}

json.dump(dataset, open(join(out_dir, out_name), 'w'))
