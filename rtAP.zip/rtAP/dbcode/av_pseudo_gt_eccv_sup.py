# Set up pseudo ground truth for object detection
from os import scandir
from os.path import join, isfile

import json, pickle
import numpy as np
from tqdm import tqdm

import pycocotools.mask as maskUtils

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2
from dbcode.dbinfo import av_classes, coco2av

data_dir = '/data2/mengtial'
data_root = join(data_dir, 'ArgoVerse1.1', 'tracking')

view = 'ring_front_center'
img_width, img_height = 1920, 1200
split = 'train'
with_mask = True

ref_db = join(data_root, 'coco_fmt', 'htc_dconv2_ms_' + split + '.json')
det_path = join(data_dir, 'Exp', 'ArgoVerse1.1', 'output-mask', 'htc_dconv2_ms_s1.0', split, 'results_ccf.pkl')
det_th = 0.3

out_dir = mkdir2(join(data_root, 'coco_fmt'))
out_name = 'htc_dconv2_ms_s1.0_mask_' + split + '.json'


db = json.load(open(ref_db))
det_results = pickle.load(open(det_path, 'rb'))

img_ids = [img['id'] for img in db['images']]

aid = 0
annots = []
for det in tqdm(det_results):
    if det['score'] < det_th:
        continue
    iid = det['image_id']
    assert iid in img_ids, iid
    bbox = det['bbox']
    if type(bbox) is np.ndarray:
        bbox = bbox.tolist()
    if with_mask:
        mask = det['segmentation']
        mask['counts'] = mask['counts'].decode(encoding='UTF-8')
        area = float(maskUtils.area(mask))
    else:
        area = float(maskUtils.area(bbox))
    ann = {
        'id': aid,
        'image_id': iid,
        'bbox': bbox,
        'category_id': int(det['category_id']),
        'area': area,
        'iscrowd': False,
        'ignore': False,
    }
    if with_mask:
        ann['segmentation'] = mask
    annots.append(ann)
    aid += 1

db['annotations'] = annots
json.dump(db, open(join(out_dir, out_name), 'w'))
