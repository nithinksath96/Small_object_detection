# Set up pseudo ground truth for object detection

from os import scandir
from os.path import join, isfile

import json, pickle
from tqdm import tqdm
import numpy as np

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2
from dbcode.dbinfo import *
from track import iou_assoc

data_dir = 'D:/Data'
data_root = join(data_dir, 'ArgoVerse1.1', 'tracking')
class_subset = acc_subset_3

view = 'ring_front_center'
img_width, img_height = 1920, 1200
split = 'val'

in_dir = join(data_dir, 'ArgoVerse1.1', 'annot_scale', 'tracking_val')

out_dir = mkdir2(join(data_root, 'coco_fmt'))
out_name = split + '_track.json'

seqs_dir = join(data_root, split)
seqs = sorted([item.name for item in scandir(seqs_dir) if item.is_dir()])
seq_dirs = [split + '/' + seq + '/' + view for seq in seqs]

iid = 0
aid = 0
imgs = []
annots = []

cats = []
class_names = []
for i, c in enumerate(class_subset):
    cats.append({'id': i, 'name': coco_classes[c]})
    class_names.append(coco_classes[c])

n_class = len(cats)

task_info = json.load(open(join(in_dir, 'task_info_chunk.json')))
task_ids = task_info['task_ids']
task_sids = task_info['task_sids']
task_seqs = task_info['task_seqs']
task_i_starts = task_info['task_i_starts']
task_i_ends = task_info['task_i_ends']
task_i_lens = task_info['task_i_lens']
n_task = len(task_ids)

labels_ignored = []
n_tracks = []
for sid, seq in enumerate(tqdm(seqs)):
    fid = 0 # frame id
    seq_imgs = sorted(
        [item.name for item in scandir(join(data_root, seq_dirs[sid]))
            if item.is_file()])
    tasks = [i for i in range(n_task) if task_sids[i] == sid]
    task_annot = []
    for t in tasks:
        raw_annot = json.load(open(join(in_dir, 'raw_annot', task_ids[t] + '.json')))
        task_annot.append(raw_annot)
    task_idx = 0
    tkidx = 0
    track_uuid = {}
    for fid, name in enumerate(seq_imgs):
        if fid >= task_i_ends[tasks[task_idx]]:
            # iou_based matching
            task_idx += 1
            fid_in_task = fid - 1 - task_i_starts[tasks[task_idx]]
            annot_next = task_annot[task_idx][fid_in_task]['annotations']

            bboxes_next = []
            labels_next = []
            uuids_next = []

            for obj in annot_next:
                label = obj['label']
                if label == 'pickup_truck':
                    # map pickup truck to truck as defined in COCO
                    label = 'truck'
                if label in class_names:
                    label = class_names.index(label)
                else:
                    if label not in labels_ignored:
                        labels_ignored.append(label)
                    continue

                uuid = obj['uuid']
                bbox = [obj['left'], obj['top'], obj['width'], obj['height']]

                bboxes_next.append(bbox)
                labels_next.append(label)
                uuids_next.append(uuid)

            order1, order2, n_matched, _, _ = iou_assoc(
                bboxes_frame, labels_frame, np.asarray(tracks_frame), tkidx,
                bboxes_next, labels_next, 0.5, True,
            )
            for o1, o2 in zip(order1, order2[:n_matched]):
                track_uuid[uuids_next[o2]] = tracks_frame[o1]

        fid_in_task = fid - task_i_starts[tasks[task_idx]]
        annot_frame = task_annot[task_idx][fid_in_task]['annotations']

        bboxes_frame = []
        labels_frame = []
        tracks_frame = []
        for obj in annot_frame:
            label = obj['label']
            if label == 'pickup_truck':
                # map pickup truck to truck as defined in COCO
                label = 'truck'
            if label in class_names:
                label = class_names.index(label)
            else:
                if label not in labels_ignored:
                    labels_ignored.append(label)
                continue

            uuid = obj['uuid']
            if uuid in track_uuid:
                track = track_uuid[uuid]
            else:
                track = tkidx
                track_uuid[uuid] = tkidx
                tkidx += 1

            bbox = [obj['left'], obj['top'], obj['width'], obj['height']]
            iscrowd = obj['attributes']['is_crowd'] == 'True'

            annots.append({
                'id': aid,
                'image_id': iid,
                'bbox': bbox,
                'category_id': label,
                'area': float(bbox[2]*bbox[3]),
                'iscrowd': iscrowd,
                'ignore': False,
                'track': track,
            })

            aid += 1

            bboxes_frame.append(bbox)
            labels_frame.append(label)
            tracks_frame.append(track)

        imgs.append({
            'id': iid,
            'sid': sid,
            'fid': fid,
            'name': name,
            'width': img_width,
            'height': img_height,
        })

        iid += 1
    n_tracks.append(tkidx)

print('labels ignored:', labels_ignored)

n_coco = len(coco_classes)
coco_mapping = n_coco*[n_coco]
for i, c in enumerate(class_subset):
    coco_mapping[c] = i

dataset = {
    'categories': cats,
    'images': imgs,
    'annotations': annots,
    'sequences': seqs,
    'seq_dirs': seq_dirs,
    'coco_subset': class_subset,
    'coco_mapping': coco_mapping,
    'n_tracks': n_tracks,
}

print(n_tracks)
print(max(n_tracks), sum(n_tracks))

json.dump(dataset, open(join(out_dir, out_name), 'w'))
