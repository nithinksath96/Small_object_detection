import tensorflow as tf


dataset = tf.data.TFRecordDataset(r'D:\Data\Waymo\tfrecord\segment-17065833287841703_2980_000_3000_000.tfrecord', compression_type='')
for data in dataset:
    frame = open_dataset.Frame()
    frame.ParseFromString(bytearray(data.numpy()))
    break