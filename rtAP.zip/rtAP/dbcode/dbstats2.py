# Set up pseudo ground truth for object detection

from os.path import join

import json
import numpy as np


import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import print_stats


db_path = r'E:\Data\COCO\annotations\instances_val2017.json'
db = json.load(open(db_path))

imgs = db['images']
ws = np.array([img['width'] for img in imgs])
hs = np.array([img['height'] for img in imgs])
areas = ws * hs

print_stats(ws, 'Width')
print_stats(hs, 'Height')
print_stats(areas/1000, 'Areas')

r2 = 1920*1200/areas.mean()
r = np.sqrt(r2)
print('Ratio^2:', r2)
print('Ratio:', r)
print('32:', 32*r)
print('96:', 96*r)

