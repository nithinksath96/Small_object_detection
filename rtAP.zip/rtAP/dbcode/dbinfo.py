coco_classes = [
    'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat', 'traffic_light', 'fire_hydrant', 'stop_sign', 'parking_meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports_ball', 'kite', 'baseball_bat', 'baseball_glove', 'skateboard', 'surfboard', 'tennis_racket', 'bottle', 'wine_glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich', 'orange', 'broccoli', 'carrot', 'hot_dog', 'pizza', 'donut', 'cake', 'chair', 'couch', 'potted_plant', 'bed', 'dining_table', 'toilet', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell_phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy_bear', 'hair_drier', 'toothbrush',
]

kmots_classes = [
    'car',
    'pedestrain',
]

av_classes = [
    'VEHICLE',
    'PEDESTRIAN',
    'ON_ROAD_OBSTACLE',
    'LARGE_VEHICLE',
    'BICYCLE',
    'BICYCLIST',
    'BUS',
    'OTHER_MOVER',
    'TRAILER',
    'MOTORCYCLIST',
    'MOPED',
    'MOTORCYCLE',
    'STROLLER',
    'EMERGENCY_VEHICLE',
    'ANIMAL',
    'WHEELCHAIR',
    'SCHOOL_BUS',
]

coco2av = {
    0: 1, # person -> pedestrian
    1: 4, # bicycle
    2: 0, # car -> vehicle
    3: 11, # motorcycle
    5: 6, # bus
}
# Unmatched classes
# "ON_ROAD_OBSTACLE": 2,
# "LARGE_VEHICLE": 3,
# "BICYCLIST": 5,
# "OTHER_MOVER": 7,
# "TRAILER": 8,
# "MOTORCYCLIST": 9,
# "MOPED": 10,
# "STROLLER": 12,
# "EMERGENCY_VEHICLE": 13,
# "ANIMAL": 14,
# "WHEELCHAIR": 15,
# "SCHOOL_BUS": 16,

coco2kmots = {
    0: 1, # person -> pedestrain
    2: 0, # car -> car
}



coco2av = {
    0: 1, # person -> pedestrian
    1: 4, # bicycle
    2: 0, # car -> vehicle
    3: 11, # motorcycle
    5: 6, # bus
}


# ArgoVerse with COCO classes
acc_subset_1 = [
    0, # person
    1, # bicycle
    2, # car
    3, # motorcycle
    5, # bus
]

acc_subset_2 = [
    0, # person
    1, # bicycle
    2, # car
    3, # motorcycle
    5, # bus
    7, # truck
]

acc_subset_3 = [
    0, # person
    1, # bicycle
    2, # car
    3, # motorcycle
    5, # bus
    7, # truck
    9, # traffic_light
    11, # stop_sign
]

acc_subset_4 = [
    0, # person
    1, # bicycle
    2, # car
    3, # motorcycle
    5, # bus
    7, # truck
    9, # traffic_light
    10, # fire_hydrant
    11, # stop_sign
]

class_colors = [
    
]