# Set up pseudo ground truth for object detection
from os import scandir
from os.path import join, isfile
from shutil import copy2

import numpy as np
from tqdm import tqdm
import json, requests, scaleapi

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2


chunk_size = 200
overlap = 3
overwrite = False

# scale_key = 'test_8b3713ce60014513900e41c8635cd126'
scale_key = 'live_77de3102d768429d89996f039135e932'
s3_prefix = 'https://achal-public.s3.amazonaws.com/martin/av1.1'
callback_url = 'https://en25b892btqow.x.pipedream.net'
instruction = '<iframe src="https://docs.google.com/document/d/e/2PACX-1vSXir32p8Va9jr0NsVsjXVzfg5IKFMlPP6o6LbCoSWisouGvHdldIfRUJFJZcIeWrHk0MMvIjFtJ5Qh/pub?embedded=true"></iframe>'
# project = 'Carnegie Mellon University_default_videoboxannotation'
project = 'Martin Efficiency Benchmark'


data_dir = 'D:/Data'

data_root = join(data_dir, 'ArgoVerse1.1', 'tracking')
view = 'ring_front_center'

split = 'val'
total_images_verification = 15062

in_dir = join(data_dir, 'ArgoVerse1.1', 'annot_scale', 'tracking_val')
out_dir = mkdir2(join(in_dir, 'raw_annot'))

seqs_dir = join(data_root, split)
seqs = sorted([item.name for item in scandir(seqs_dir) if item.is_dir()])
seq_dirs = [split + '/' + seq + '/' + view for seq in seqs]

task_info = json.load(open(join(in_dir, 'task_info_chunk.json')))
task_ids = task_info['task_ids']

client = scaleapi.ScaleClient(scale_key)

task_page = client.tasks(project=project, status='completed')
assert task_page.total < task_page.limit # a single fetch has limitations


for task_response in tqdm(task_page.docs):
    if task_response.id not in task_ids:
        continue
    out_file = join(out_dir, task_response.id + '.json')
    if not overwrite and isfile(out_file):
        continue

    annot_url = task_response.param_dict['response']['annotations']['url']
    annot_data = requests.get(annot_url, auth=(scale_key, ''))
    assert annot_data.ok
    annot_data = annot_data.json()
    json.dump(annot_data, open(out_file, 'w'))

