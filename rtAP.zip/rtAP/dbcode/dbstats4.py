# Set up pseudo ground truth for object detection

from os.path import join

import json
import numpy as np

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import print_stats


db_path = 'D:/Data/ArgoVerse1.1/tracking/coco_fmt/val_c3.json'
db = json.load(open(db_path))

seqs = db['sequences']
seq_len = []
for sid, seq in enumerate(seqs):
    frame_list = [img for img in db['images'] if img['sid'] == sid]
    seq_len.append(len(frame_list)/30)

print(seq_len)

