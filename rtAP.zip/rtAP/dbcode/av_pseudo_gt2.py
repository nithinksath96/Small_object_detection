# Set up pseudo ground truth for object detection
# with a new class set
from os import scandir
from os.path import join, isfile

import json, pickle
import numpy as np
from tqdm import tqdm

import pycocotools.mask as maskUtils

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2
from dbcode.dbinfo import coco_classes

relevant_classes = [
'person', 'bicycle', 'car', 
'motorcycle', 'bus', 'truck',
'traffic_light', 'fire_hydrant', 'stop_sign', 
]
subset = [coco_classes.index(c) for c in relevant_classes]

data_dir = '/data2/mengtial'
data_root = join(data_dir, 'ArgoVerse', 'tracking')

view = 'ring_front_center'
img_width, img_height = 1920, 1200
split = 'val'

det_dir = join(data_dir, 'Exp', 'ArgoVerse', 'htc_dconv2_ms', split)
det_th = 0.3

out_dir = mkdir2(join(data_root, 'coco_fmt'))
out_name = 'htc_dconv2_ms_' + split + '_2.json'

seqs_dir = join(data_root, split)
seqs = sorted([item.name for item in scandir(seqs_dir) if item.is_dir()])
seq_dirs = [split + '/' + seq + '/' + view for seq in seqs]

iid = 0
aid = 0
imgs = []
annots = []

cats = []
for i, c in enumerate(subset):
    cats.append({'id': i, 'name': relevant_classes[i]})

n_class = len(subset)
class_cnt = n_class*[0]

for sid, seq in enumerate(tqdm(seqs)):
    fid = 0 # frame id
    seq_imgs = sorted(
        [item.name for item in scandir(join(data_root, seq_dirs[sid]))
            if item.is_file()])
    for fid, name in enumerate(seq_imgs):
        det = pickle.load(open(join(det_dir, seq, name[:-3] + 'pkl'), 'rb'))
        bboxes, masks = det

        # class mapping in mmdet format
        mapped = [np.empty((0, 5)) for c in range(n_class)]
        for c, row in enumerate(bboxes):
            if c in subset:
                new_c = subset.index(c)
                mapped[new_c] = row
        bboxes = mapped

        mapped = [np.empty((0, 5)) for c in range(n_class)]
        for c, row in enumerate(masks):
            if c in subset:
                new_c = subset.index(c)
                mapped[new_c] = row
        masks = mapped

        # convert to coco fmt
        for c, row in enumerate(bboxes):
            for i in range(row.shape[0]):
                bbox = row[i]
                score = bbox[4]
                if score < det_th:
                    continue
                bbox = bbox[:4]
                bbox[2:] -= bbox[:2]

                mask = masks[c][i]
                mask['counts'] = mask['counts'].decode(encoding='UTF-8')

                annots.append({
                    'id': aid,
                    'image_id': iid,
                    'bbox': bbox.tolist(),
                    'category_id': c,
                    'segmentation': mask,
                    'area': float(maskUtils.area(mask)),
                    'iscrowd': False,
                    'ignore': False,
                })

                aid += 1
                class_cnt[c] += 1

        imgs.append({
            'id': iid,
            'sid': sid,
            'fid': fid,
            'name': name,
            'width': img_width,
            'height': img_height,
        })

        iid += 1

print(class_cnt)
idx = np.argsort(class_cnt)[::-1]
print(idx)
for i in idx:
    print('%s: %d' % (relevant_classes[i], class_cnt[i]))

dataset = {
    'categories': cats,
    'images': imgs,
    'annotations': annots,
    'sequences': seqs,
    'seq_dirs': seq_dirs,
    'class_count': class_cnt,
}

json.dump(dataset, open(join(out_dir, out_name), 'w'))