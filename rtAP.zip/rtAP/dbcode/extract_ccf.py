# Set up pseudo ground truth for object detection

from os.path import join, isfile
from os import scandir

from shutil import copy2

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2

work_dir = '/data2/mengtial/Exp/ArgoVerse1.1/output'
split = 'val'
out_dir = mkdir2('/data2/mengtial/extract')

filter_list = [
    'ssd512_s0.2',
    'ssd512_s0.25',
    'ssd512_s0.5',
    'ssd512_s0.75',
    'ssd512_s1.0',
    'retina50_s0.2',
    'retina50_s0.25',
    'retina50_s0.5',
    'retina50_s0.75',
    'retina50_s1.0',
    'retina101_s0.2',
    'retina101_s0.25',
    'retina101_s0.5',
    'retina101_s0.75',
    'retina101_s1.0',
    'mrcnn50_nm_s0.2',
    'mrcnn50_nm_s0.25',
    'mrcnn50_nm_s0.5',
    'mrcnn50_nm_s0.75',
    'mrcnn50_nm_s1.0',
    'mrcnn101_nm_s0.2',
    'mrcnn101_nm_s0.25',
    'mrcnn101_nm_s0.5',
    'mrcnn101_nm_s0.75',
    'mrcnn101_nm_s1.0',
    'cmrcnn50_nm_s0.2',
    'cmrcnn50_nm_s0.25',
    'cmrcnn50_nm_s0.5',
    'cmrcnn50_nm_s0.75',
    'cmrcnn50_nm_s1.0',
    'cmrcnn101_nm_s0.2',
    'cmrcnn101_nm_s0.25',
    'cmrcnn101_nm_s0.5',
    'cmrcnn101_nm_s0.75',
    'cmrcnn101_nm_s1.0',
    'htc_dconv2_ms_nm_s0.2',
    'htc_dconv2_ms_nm_s0.25',
    'htc_dconv2_ms_nm_s0.5',
    'htc_dconv2_ms_nm_s0.75',
    'htc_dconv2_ms_nm_s1.0',
]

cnt = 0
for d in scandir(work_dir):
    if d.is_dir():
        if d.name not in filter_list:
            print(f'Skipping "{d.name}", which is not in filter list')
            continue
        src = join(work_dir, d.name, split, 'results_ccf.pkl')
        if not isfile(src):
            print(f'Skipping "{d.name}", which does not have ccf result')
            continue
        dst = mkdir2(join(out_dir, d.name, split))
        copy2(join(work_dir, d.name, split, 'results_ccf.pkl'), dst)
        cnt += 1

print(f'{cnt} files copied')


