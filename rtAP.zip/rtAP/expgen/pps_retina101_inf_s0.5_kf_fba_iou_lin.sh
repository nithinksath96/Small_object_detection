dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python forecast/pps_forecast_kf.py \
	--fps 30 \
	--eta 0 \
	--assoc iou \
	--forecast-before-assoc \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--in-dir "$dataDir/Exp/ArgoVerse1.1/output/srt_retina101_inf_s0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/pps_retina101_inf_s0.5_kf_fba_iou_lin/val" \
