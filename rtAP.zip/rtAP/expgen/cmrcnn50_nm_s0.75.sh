dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/det_coco_fmt.py \
	--no-mask \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--config "$HOME/repo/mmdetection/configs/cascade_mask_rcnn_r50_fpn_1x.py" \
	--weights "$ssdDir/ModelZoo/mmdet/cascade_mask_rcnn_r50_fpn_20e_20181123-6e0c9713.pth" \
	--in-scale 0.75 \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/cmrcnn50_nm_s0.75/val" \
