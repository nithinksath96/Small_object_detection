dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/rt_det_coco_fmt.py \
    --no-mask \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--config "train/cfg/faster_rcnn_r50_fpn_ft_av.py" \
	--weights "$dataDir/Exp/ArgoVerse1.1/train/frcnn_ft_e3_lr2e-2/latest.pth" \
	--no-class-mapping \
	--in-scale 0.5 \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output2/rt_frcnn_ft_e3_lr2e-2_ts0.5/val" \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1/output2/rt_frcnn_ft_e3_lr2e-2_ts0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output2/rt_frcnn_ft_e3_lr2e-2_ts0.5/val" \
