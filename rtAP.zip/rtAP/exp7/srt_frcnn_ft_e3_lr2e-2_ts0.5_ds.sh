dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python util/add_to_runtime_zoo.py \
	--overwrite \
	--time-info "$dataDir/Exp/ArgoVerse1.1/output2/rt_frcnn_ft_e3_lr2e-2_ts0.5/val/time_info.pkl" \
	--out-path "$dataDir/Exp/ArgoVerse1.1/runtime-zoo/1080ti/frcnn_ft_s0.5.pkl" \
    && 
python det/srt_det_coco_fmt.py \
	--dynamic-schedule \
	--no-mask \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--cached-res "$dataDir/Exp/ArgoVerse1.1/output2/rt_frcnn_ft_e3_lr2e-2_ts0.5/val/results_ccf.pkl" \
	--runtime "$dataDir/Exp/ArgoVerse1.1/runtime-zoo/1080ti/frcnn_ft_s0.5.pkl" \
	--in-scale 0.5 \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output2/srt_frcnn_ft_e3_lr2e-2_ts0.5_ds/val" \
    &&
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1/output2/rt_frcnn_ft_e3_lr2e-2_ts0.5/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output2/rt_frcnn_ft_e3_lr2e-2_ts0.5/val" \
