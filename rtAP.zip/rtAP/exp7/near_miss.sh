dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ModelZoo/mmdet" ]; then
  ssdDir="$dataDir"
fi

dbName="near_miss"
vidPath="$dataDir/Random/near_miss/near_miss.mp4"
vidDBDir="$dataDir/Random/near_miss"
config="$HOME/repo/mmdetection/configs/htc/htc_dconv_c3-c5_mstrain_400_1400_x101_64x4d_fpn_20e.py"
weights="$ssdDir/ModelZoo/mmdet/htc_dconv_c3-c5_mstrain_400_1400_x101_64x4d_fpn_20e_20190408-0e50669c.pth"

# fps=23.98

imgFolder="$vidDBDir/frames"

# mkdir -p "$imgFolder"
# ffmpeg -i "$vidPath" -qscale:v 2 "$imgFolder/%06d.jpg"

# Verify FPS
fps=`ffmpeg -i "$vidPath" 2>&1 | sed -n "s/.*, \(.*\) fp.*/\1/p"`
echo FPS-ffmpeg: $fps


# python dbcode/db_from_img_folder.py \
# 	--img-folder "$imgFolder" \
# 	--prefix "frames" \
# 	--out-path "$vidDBDir/db.json" \
# 	--overwrite \
# 	&&
python det/srt_det_coco_fmt.py \
	--fps $fps \
	--overwrite \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--config "$config" \
	--weights "$weights" \
	--in-scale 1 \
	--out-dir "$dataDir/Exp/$dbName/output/rt_htc_s1.0/" \
	--runtime "$dataDir/Exp/ArgoVerse1.1/runtime-zoo/1080ti/htc_dconv2_ms_nm_s1.0.pkl" \
	&&
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--overwrite \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--result-dir "$dataDir/Exp/$dbName/output/rt_htc_s1.0/" \
	--out-dir "$dataDir/Exp/$dbName/output/rt_htc_s1.0/" \
	--no-eval \
	&&
python vis/vis_det_fancy.py \
	--seq 0 \
	--fps $fps \
	--data-root "$vidDBDir" \
	--annot-path "$vidDBDir/db.json" \
	--result-path "$dataDir/Exp/$dbName/output/rt_htc_s1.0/results_ccf.pkl" \
	--vis-dir "$dataDir/Exp/$dbName/visf/rt_htc_s1.0/" \
	--overwrite \
	--make-video \

echo $dataDir/Exp/$dbName/visf/rt_htc_s1.0/
