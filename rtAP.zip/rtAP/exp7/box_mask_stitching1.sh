dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python util/box_mask_stitching.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/htc_dconv2_ms_s1.0_mask_val.json" \
	--box-ccf-path "$dataDir/Exp/ArgoVerse1.1/output/pps_mrcnn50_ds_s0.5_kf_fba_iou_lin/val/results_ccf.pkl" \
	--mask-ccf-path "$dataDir/Exp/ArgoVerse1.1/output/mrcnn50_s0.5/val/results_ccf.pkl" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/box_mask_stitching/val" \
	--overwrite \
	--vis-dir "$dataDir/Exp/ArgoVerse1.1/vis/box_mask_stitching/val" \

# python det/eval_coco_fmt.py \
# 	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/htc_dconv2_ms_s1.0_mask_val.json" \
# 	--result-path "$dataDir/Exp/ArgoVerse1.1/output/box_mask_stitching/val/results_ccf.pkl" \
# 	--out-dir "$dataDir/Exp/ArgoVerse1.1/output/box_mask_stitching/val" \
# 	--eval-mask \
# 	--overwrite \


