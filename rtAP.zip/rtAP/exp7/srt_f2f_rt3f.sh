dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

# needs to manually modify the srt script to
# result_from_ccf(cached_res, img['id'] ** + 3 **, cache_end_idx)

python det/srt_det_coco_fmt.py \
	--no-mask \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--cached-res "$dataDir/Exp/ArgoVerse1.1-om/output/dist_r50_fpn_f2f_h2f3_e12_s0.5/val/results_ccf.pkl" \
	--runtime "$dataDir/Exp/ArgoVerse1.1/runtime-zoo/1080ti/mrcnn50_nm_s0.75.pkl" \
	--in-scale 0.5 \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output-train/srt_f2f_rt3f/val" \
    && 
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--vis-scale 0.5 \
	--overwrite \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--result-dir "$dataDir/Exp/ArgoVerse1.1/output-train/srt_f2f_rt3f/val" \
	# --vis-dir "$dataDir/Exp/ArgoVerse1.1-debug/srt_f2f_rt3f" \
