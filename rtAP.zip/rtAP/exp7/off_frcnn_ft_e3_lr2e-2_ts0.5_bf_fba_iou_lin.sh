dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python track/off_bbox_filter.py \
	--fps 30 \
	--eta 0 \
	--n-future 3 \
	--assoc iou \
	--forecast-before-assoc \
	--forecast linear \
	--vis-scale 0.5 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--det-ccf-path "$dataDir/Exp/ArgoVerse1.1/output-train/frcnn_ft_e3_lr2e-2_ts0.5/val/results_ccf.pkl" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output-train/frcnn_ft_e3_lr2e-2_ts0.5_bf_fba_iou_lin/val" \
	--overwrite \
	# --vis-dir "$dataDir/Exp/ArgoVerse1.1/vis/pps_mrcnn50_nm_ds_s0.5_2_bf_kf1/val" \

	# --forecast-before-assoc \
	
