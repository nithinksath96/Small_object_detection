dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

# need to manually change to "dt = ii - ifidx - 3"

python forecast/pps_forecast_kf.py \
	--overwrite \
	--fps 30 \
	--eta 0 \
	--assoc iou \
	--forecast-before-assoc \
	--vis-scale 0.5 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--in-dir "$dataDir/Exp/ArgoVerse1.1/output-train/srt_f2f_rt3f_inf/val" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output-train/pps_f2f_rt3f_inf_kf/val" \
