dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python det/det_inf_multi.py \
	--fps 30 \
	--vis-scale 0.5 \
	--forecast kf \
	--forecast-before-assoc \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--exp-dir "$dataDir/Exp" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output2/inf_multi1/val" \
	--overwrite \
	# --vis-dir "$dataDir/Exp/ArgoVerse1.1/vis/pps_mrcnn50_nm_ds_s0.5_2_bf_kf1/val" \

	# --forecast-before-assoc \
	
