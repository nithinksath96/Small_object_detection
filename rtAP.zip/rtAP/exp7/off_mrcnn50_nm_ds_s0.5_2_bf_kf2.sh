dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/ArgoVerse1.1/tracking" ]; then
  ssdDir="$dataDir"
fi


python track/off_bbox_filter.py \
	--fps 30 \
	--eta 0 \
	--n-future 0 \
	--assoc iou \
	--forecast kf \
	--vis-scale 0.5 \
	--data-root "$ssdDir/ArgoVerse1.1/tracking" \
	--annot-path "$dataDir/ArgoVerse1.1/tracking/coco_fmt/val.json" \
	--det-ccf-path "$dataDir/Exp/ArgoVerse1.1-om/output/dist_r50_fpn_f2f_h2f3_e12_s0.5/val/results_ccf.pkl" \
	--out-dir "$dataDir/Exp/ArgoVerse1.1/output2/f2f_ts0.5_bf_kf1/val" \
	--overwrite \
	# --vis-dir "$dataDir/Exp/ArgoVerse1.1/vis/pps_mrcnn50_nm_ds_s0.5_2_bf_kf1/val" \

	# --forecast-before-assoc \
	
