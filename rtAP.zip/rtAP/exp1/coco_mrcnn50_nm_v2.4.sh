dataDir="/data/mengtial"
dataDir2="/data2/mengtial"

python det/det_coco.py \
	--no-mask \
	--overwrite \
	--data-root "${dataDir}/COCO/val2017" \
	--annot-path "${dataDir}/COCO/annotations/instances_val2017.json" \
	--config "$HOME/repo/mmdetection2.4/configs/mask_rcnn/mask_rcnn_r50_fpn_2x_coco.py" \
	--weights "$dataDir2/ModelZoo/mmdet/mask_rcnn_r50_fpn_2x_coco_bbox_mAP-0.392__segm_mAP-0.354_20200505_003907-3e542a40.pth" \
	--out-dir "$dataDir2/Exp/COCO/output/mrcnn50_nm_v2.4_s1.0/val" \

