# Run detection in real-time setting on a COCO-format dataset

import argparse, json, pickle
from os.path import join, isfile, basename

from tqdm import tqdm
import numpy as np

import torch

from pycocotools.coco import COCO

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2, print_stats
from util.bbox import ltwh2ltrb_
from mmdet.apis import inference_detector, init_detector

def main():
    config = r"..\mmdetection2.4\configs\mask_rcnn\mask_rcnn_r50_fpn_2x_coco.py"
    weights = r"D:\Data\ModelZoo\mmdet\mask_rcnn_r50_fpn_2x_coco_bbox_mAP-0.392__segm_mAP-0.354_20200505_003907-3e542a40.pth"
    img_path = r'D:\Data\Argoverse-1.1\tracking\val\00c561b9-2057-358d-82c6-5b06d76cebcf\ring_front_center\ring_front_center_315969629022515560.jpg'

    model = init_detector(config, weights)
    result = inference_detector(model, img_path)
    # print(result)
   

if __name__ == '__main__':
    main()