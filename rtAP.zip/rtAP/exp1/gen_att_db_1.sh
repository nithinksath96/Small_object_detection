dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/Argoverse-1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

python att/gen_gt_off_zoom_in.py \
	--data-root "$ssdDir/Argoverse-1.1/tracking" \
	--annot-path "$dataDir/Argoverse-HD/annotations/val.json" \
	--det1-path "$dataDir/Exp/Argoverse-HD/output/mrcnn50_nm_s0.5/val/results_ccf.pkl" \
	--det2-path "$dataDir/Exp/Argoverse-HD/output/mrcnn50_nm_cs_s1.0/val/results_ccf.pkl" \
	--out-path "$dataDir/Exp/Argoverse-HD/att/zoom-db-1.npz" \
	--overwrite \
	--n-worker 28 \
	--batch-size 280 \

