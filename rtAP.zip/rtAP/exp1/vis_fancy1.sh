dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/Argoverse-1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

methodName=mrcnn50_nm_s0.5

python vis/vis_det_fancy.py \
	--data-root "${ssdDir}/Argoverse-1.1/tracking" \
	--annot-path "${dataDir}/Argoverse-HD/annotations/val.json" \
	--result-path "${dataDir}/Exp/Argoverse-HD/output/${methodName}/val/results_ccf.pkl" \
	--vis-dir "${dataDir}/Exp/Argoverse-HD/visf-th0.3/${methodName}/val" \
	--score-th 0.3 \
	--overwrite \

