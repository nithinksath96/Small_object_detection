dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/Argoverse-1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

methodName=mrcnn50_nm_s0.75

python det/srt_det_coco_fmt.py \
	--dynamic-schedule \
	--no-mask \
	--fps 30 \
	--overwrite \
	--data-root "$ssdDir/Argoverse-1.1/tracking" \
	--annot-path "$dataDir/Argoverse-HD/annotations/val.json" \
	--cached-res "$dataDir/Exp/Argoverse-HD/output/${methodName}/val/results_raw.pkl" \
	--runtime "$dataDir/Exp/Argoverse-HD/runtime-zoo/1080ti/${methodName}.pkl" \
	--out-dir "$dataDir/Exp/Argoverse-debug/output/srt_mrcnn50_nm_ds_s0.75/val" \
