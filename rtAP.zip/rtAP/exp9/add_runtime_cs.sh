dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/Argoverse-1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

methodName=mrcnn50_nm_cs_s1.0

python util/add_to_runtime_zoo.py \
	--time-info "${dataDir}/Exp/Argoverse-HD/output/${methodName}/val/time_info.pkl" \
	--out-path "${dataDir}/Exp/Argoverse-HD/runtime-zoo/1080ti/${methodName}.pkl" \
