dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/Argoverse-1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

scriptName="$(basename "$(test -L "$0" && readlink "$0" || echo "$0")")" 
expName=${scriptName%.*}

python det/srt_det_multi.py \
	--dynamic-schedule \
	--no-mask \
	--overwrite \
	--data-root "$ssdDir/Argoverse-1.1/tracking" \
	--annot-path "$dataDir/Argoverse-HD/annotations/val.json" \
	--out-dir "$dataDir/Exp/Argoverse-HD/output/${expName}/val" \
    &&
python det/rt_assoc_eval.py \
	--fps 30 \
	--eta 0 \
	--overwrite \
	--data-root "$ssdDir/Argoverse-1.1/tracking" \
	--annot-path "$dataDir/Argoverse-HD/annotations/val.json" \
	--result-dir "$dataDir/Exp/Argoverse-HD/output/${expName}/val" \
