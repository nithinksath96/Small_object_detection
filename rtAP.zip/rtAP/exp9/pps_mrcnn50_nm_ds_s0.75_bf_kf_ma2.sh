dataDir="/data2/mengtial"
ssdDir="/scratch/mengtial"
if [ ! -d "$ssdDir/Argoverse-1.1/tracking" ]; then
  ssdDir="$dataDir"
fi

scriptName="$(basename "$(test -L "$0" && readlink "$0" || echo "$0")")" 
expName=${scriptName%.*}

python track/pps_bbox_filter.py \
	--fps 30 \
	--eta 0 \
	--assoc iou \
	--forecast kf \
	--forecast-before-assoc \
	--max-age 2 \
	--data-root "$ssdDir/Argoverse-1.1/tracking" \
	--annot-path "$dataDir/Argoverse-HD/annotations/val.json" \
	--in-dir "$dataDir/Exp/Argoverse-HD/output/srt_mrcnn50_nm_ds_s0.75/val" \
	--out-dir "$dataDir/Exp/Argoverse-HD/output/${expName}/val" \
	--overwrite \

	
