# Generate ground truth for training offline zoom in policy

import argparse, json, pickle
from os.path import join, isfile, dirname
from os import makedirs
from time import perf_counter

from tqdm import tqdm
import numpy as np

# maybe clashing with pytorch on trinity, needs to import it first
from filterpy.kalman import KalmanFilter

# using pytorch's dataloader for parallel processing
from torch.utils import data

from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

import sys; sys.path.insert(0, '..'); sys.path.insert(0, '.')
from util import mkdir2, print_stats
from util.bbox import ltwh2ltrb
from det import imread, eval_ccf, result_from_ccf
from track import vis_track
from track.bbox_filter import BboxFilter


def parse_args():
    parser = argparse.ArgumentParser()
    # parser.add_argument('--data-root', type=str, required=True)
    # parser.add_argument('--annot-path', type=str, required=True)
    # parser.add_argument('--fps', type=float, default=30)
    # parser.add_argument('--assoc', type=str, default='iou')
    # parser.add_argument('--match-iou-th', type=float, default=0.3)
    # parser.add_argument('--forecast', type=str, default='kf')
    # parser.add_argument('--forecast-before-assoc', action='store_true', default=False)
    # parser.add_argument('--det1-path', type=str, required=True)
    # parser.add_argument('--det2-path', type=str, required=True)
    # parser.add_argument('--batch-size', type=int, default=128)
    # parser.add_argument('--n-worker', type=int, default=32)
    # parser.add_argument('--n-exp', type=int, default=float('inf'))
    # parser.add_argument('--out-path', type=str, required=True)
    # parser.add_argument('--overwrite', action='store_true', default=False)


    parser.add_argument('--data-root', type=str, default='D:/Data/Argoverse-1.1/tracking')
    parser.add_argument('--annot-path', type=str, default='D:/Data/Argoverse-HD/annotations/val.json')
    parser.add_argument('--fps', type=float, default=30)
    parser.add_argument('--assoc', type=str, default='iou')
    parser.add_argument('--match-iou-th', type=float, default=0.3)
    parser.add_argument('--forecast', type=str, default='kf')
    parser.add_argument('--forecast-before-assoc', action='store_true', default=False)
    parser.add_argument('--det1-path', type=str, default='D:/Data/Exp/Argoverse-HD/output/mrcnn50_nm_s0.5/val/results_ccf.pkl')
    parser.add_argument('--det2-path', type=str, default='D:/Data/Exp/Argoverse-HD/output/mrcnn50_nm_cs_s1.0/val/results_ccf.pkl')
    parser.add_argument('--batch-size', type=int, default=800)
    parser.add_argument('--n-worker', type=int, default=0)
    parser.add_argument('--n-exp', type=int, default=float('inf'))
    parser.add_argument('--out-path', type=str, default='D:/Data/Exp/Argoverse-HD/att/zoom-db-1.npz')
    parser.add_argument('--overwrite', action='store_true', default=True)

    opts = parser.parse_args()
    return opts

def evalAP(self):
    '''
        Run evaluation silently and returns just the overall AP
    '''
    self.evaluate()
    self.accumulate()
    
    s = self.eval['precision']

    # p = self.params
    # aind = [i for i, aRng in enumerate(p.areaRngLbl) if aRng == 'all']
    # mind = [i for i, mDet in enumerate(p.maxDets) if mDet == 100]
    # s = s[:,:,:,aind,mind]
    regionAll = 0
    maxDet100 = 2
    s = s[:, :, :, regionAll, maxDet100]

    # if the line below throws an arrow, there means no GT for all classes
    AP = np.mean(s[s>-1])
    return AP
COCOeval.evalAP = evalAP

class ExpertDataset(data.Dataset):
    def __init__(self, opts):
        self.unroll = 3
        self.rtf = 2
        self.sample_paths = [
            [0, 0, 0, 0],
            [0, 0, 0, 1],
            [0, 0, 1, 0],
            [0, 1, 0, 0],
            [0, 1, 0, 1],
        ]

        db = COCO(opts.annot_path)
        seqs = db.dataset['sequences']
        n_seq = len(seqs)
        # remove boundary cases
        self.imgs = list(db.imgs.values())
        self.valid_idx = []
        for sid in range(n_seq):
            frame_list = [img['id'] for img in db.imgs.values() if img['sid'] == sid]
            self.valid_idx += frame_list[:-(self.unroll + self.rtf)]

        det1 = pickle.load(open(opts.det1_path, 'rb'))
        det2 = pickle.load(open(opts.det2_path, 'rb'))
        
        iids = [img['id'] for img in self.imgs]
        self.dets = [self.cvt_ccf(det1, iids), self.cvt_ccf(det2, iids)]

        self.w_img, self.h_img = db.imgs[0]['width'], db.imgs[0]['height']
        self.forecast = opts.forecast
        self.forecast_before_assoc = opts.forecast_before_assoc
        self.db = db
        dummy_ann = {'id': 0, 'image_id': 0}
        self.cocoEval = COCOeval(db, db.loadRes([dummy_ann]), 'bbox')

    def cvt_ccf(self, ccf, iids):
        results = len(iids)*[None]
        end_idx = 0
        for i, iid in enumerate(iids):
            end_idx, bboxes, scores, labels, _ = \
                result_from_ccf(ccf, iid, end_idx)
            results[i] = [bboxes, scores, labels]
        return results

    def __len__(self):
        return len(self.valid_idx)

    def __getitem__(self, index):
        APs = len(self.sample_paths)*[None]
        for si, sp in enumerate(self.sample_paths):
            results_ccf = []
            bf = BboxFilter(
                self.w_img, self.h_img,
                forecast=self.forecast,
                forecast_before_assoc=self.forecast_before_assoc,
            )

            img_ids = []
            for ii in range(self.unroll + 1):
                det_idx = self.valid_idx[index] + ii
                img = self.imgs[self.valid_idx[index] + ii + self.rtf]
                img_ids.append(img['id'])
                bboxes, scores, labels = self.dets[sp[ii]][det_idx]
                bf.update(bboxes, scores, labels, None, dt=1)
                bboxes_t3, scores_t3, labels_t3, _, _ = \
                    bf.predict(self.rtf)

                n = len(bboxes_t3)
                for i in range(n):
                    result_dict = {
                        'image_id': img['id'],
                        'bbox': bboxes_t3[i],
                        'score': scores_t3[i],
                        'category_id': labels_t3[i],
                    }
                    results_ccf.append(result_dict)
            self.cocoEval.params.imgIds = img_ids
            self.cocoEval.cocoDt = self.db.loadRes(results_ccf)
            APs[si] = self.cocoEval.evalAP()
        sel = np.argmax(APs)
        gt = self.sample_paths[sel][0]
        return self.imgs[self.valid_idx[index]]['id'], gt, sel

def identity_map(x):
        # using this dummy function instead of lambda
        # since it needs to be pickable
        return x

def main():
    opts = parse_args()
    if not opts.overwrite and isfile(opts.out_path):
        print('File already exists, exiting')
        return

    loader = data.DataLoader(
        ExpertDataset(opts),
        batch_size=opts.batch_size,
        shuffle=True,
        num_workers=opts.n_worker,
        collate_fn=identity_map, 
    )

    makedirs(dirname(opts.out_path), exist_ok=True)

    att_db = []
    for batch in tqdm(loader):
        # the actual batch size might be smaller than opts.batch_size
        att_db += batch
        if len(att_db) >= opts.n_exp:
            break
    att_db = np.array(att_db).transpose()
    if isinstance(opts.n_exp, int):
        att_db = att_db[:opts.n_exp]
    np.savez_compressed(opts.out_path, att_db=att_db)

if __name__ == '__main__':
    main()